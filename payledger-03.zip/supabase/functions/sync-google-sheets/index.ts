// supabase/functions/sync-google-sheets/index.ts
// Optional Google Sheets synchronization processor.
// Reads pending items from public.integration_sync_queue.
// If GOOGLE_SHEETS_SERVICE_ACCOUNT_JSON or GOOGLE_SHEETS_SPREADSHEET_ID are absent, exits gracefully without affecting Supabase records.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const sheetsCreds = Deno.env.get('GOOGLE_SHEETS_SERVICE_ACCOUNT_JSON');
    const spreadsheetId = Deno.env.get('GOOGLE_SHEETS_SPREADSHEET_ID');

    if (!sheetsCreds || !spreadsheetId) {
      return new Response(
        JSON.stringify({
          configured: false,
          message: 'Optional Google Sheets secrets are not configured. Supabase remains the primary database.',
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const client = createClient(supabaseUrl, serviceRoleKey);
    const { data: pending, error } = await client
      .from('integration_sync_queue')
      .select('*')
      .in('status', ['PENDING', 'FAILED'])
      .order('created_at', { ascending: true })
      .limit(50);

    if (error) throw error;

    // Note: Production Google JWT signing & Sheets API v4 append/upsert goes here using sheetsCreds + spreadsheetId
    return new Response(
      JSON.stringify({ configured: true, queued_count: pending?.length ?? 0 }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (err) {
    return new Response(JSON.stringify({ error: (err as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
