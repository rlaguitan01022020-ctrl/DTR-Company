// supabase/functions/record-attendance/index.ts
// Trusted Edge Function for recording Employee Number attendance atomically via PostgreSQL RPC

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const client = createClient(supabaseUrl, serviceRoleKey);

    const { employee_number, pin, source, device_info } = await req.json();
    if (!employee_number || typeof employee_number !== 'string') {
      return new Response(
        JSON.stringify({ success: false, error_code: 'MISSING_EMPLOYEE_NUMBER', message: 'Employee Number is required.' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { data, error } = await client.rpc('record_employee_number_attendance', {
      p_employee_number: employee_number,
      p_pin: pin ?? null,
      p_source: source ?? 'KIOSK',
      p_device_info: device_info ?? req.headers.get('user-agent'),
    });

    if (error) throw error;

    return new Response(JSON.stringify(data), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    return new Response(JSON.stringify({ success: false, message: (err as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
