-- 0002_rls_and_functions.sql
-- Row Level Security (RLS), Auth Profile Sync, First Super Admin Provisioning & Atomic Employee Number Attendance

-- Helper functions
CREATE OR REPLACE FUNCTION public.current_user_role()
RETURNS public.user_role
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM public.profiles WHERE id = auth.uid() AND is_active = true LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.current_employee_id()
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT employee_id FROM public.profiles WHERE id = auth.uid() AND is_active = true LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.has_permission(perm_key text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(
    (SELECT (role = 'SUPER_ADMIN') OR COALESCE((permissions ->> perm_key)::boolean, false)
     FROM public.profiles WHERE id = auth.uid() AND is_active = true LIMIT 1),
    false
  );
$$;

-- Sync new auth.users into public.profiles (stores all user profile data in database)
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, role, is_active)
  VALUES (
    NEW.id,
    COALESCE(NEW.email, ''),
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', split_part(COALESCE(NEW.email, 'user'), '@', 1)),
    'EMPLOYEE',
    true
  )
  ON CONFLICT (id) DO UPDATE
  SET email = EXCLUDED.email,
      updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Secure First Super Admin Provisioning (only succeeds if 0 active SUPER_ADMIN profiles exist)
CREATE OR REPLACE FUNCTION public.provision_first_super_admin(p_full_name text, p_phone text DEFAULT NULL)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_super_count integer;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Authentication required';
  END IF;

  SELECT COUNT(*) INTO v_super_count FROM public.profiles WHERE role = 'SUPER_ADMIN' AND is_active = true;
  IF v_super_count > 0 THEN
    RAISE EXCEPTION 'A Super Admin already exists. Contact an existing Super Admin to grant access.';
  END IF;

  UPDATE public.profiles
  SET role = 'SUPER_ADMIN',
      full_name = COALESCE(NULLIF(trim(p_full_name), ''), full_name),
      phone = COALESCE(p_phone, phone),
      permissions = '{
        "can_edit_salary": true,
        "can_manage_payroll": true,
        "can_manage_holidays": true,
        "can_view_reports": true
      }'::jsonb,
      updated_at = now()
  WHERE id = v_uid;

  INSERT INTO public.audit_logs (actor_user_id, actor_role, action, table_name, record_id, new_value, reason)
  VALUES (v_uid, 'SUPER_ADMIN', 'PROVISION_FIRST_SUPER_ADMIN', 'profiles', v_uid::text, jsonb_build_object('role', 'SUPER_ADMIN'), 'Initial workspace Super Admin setup');

  RETURN jsonb_build_object('success', true, 'user_id', v_uid, 'role', 'SUPER_ADMIN');
END;
$$;

-- Safe Employee Number Lookup for Terminal & Kiosk (exposes no salary or private data)
CREATE OR REPLACE FUNCTION public.lookup_employee_for_kiosk(p_employee_number text)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_emp public.employees%ROWTYPE;
  v_work_date date := (now() AT TIME ZONE 'Asia/Manila')::date;
  v_att public.attendance%ROWTYPE;
  v_sched public.schedules%ROWTYPE;
  v_manila_ts timestamp := (now() AT TIME ZONE 'Asia/Manila');
  v_next_event text := 'TIME_IN';
BEGIN
  SELECT * INTO v_emp FROM public.employees WHERE upper(trim(employee_number)) = upper(trim(p_employee_number)) LIMIT 1;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('found', false);
  END IF;

  SELECT * INTO v_sched FROM public.schedules WHERE id = v_emp.schedule_id LIMIT 1;
  IF FOUND AND v_sched.is_overnight AND (v_manila_ts::time < v_sched.time_in) THEN
    SELECT * INTO v_att FROM public.attendance
    WHERE employee_id = v_emp.id AND work_date = (v_work_date - 1) AND actual_time_in IS NOT NULL AND actual_time_out IS NULL
    LIMIT 1;
    IF FOUND THEN
      v_work_date := v_work_date - 1;
    END IF;
  END IF;

  SELECT * INTO v_att FROM public.attendance WHERE employee_id = v_emp.id AND work_date = v_work_date LIMIT 1;
  IF FOUND AND v_att.actual_time_in IS NOT NULL AND v_att.actual_time_out IS NULL THEN
    v_next_event := 'TIME_OUT';
  END IF;

  RETURN jsonb_build_object(
    'found', true,
    'employee_number', v_emp.employee_number,
    'full_name', v_emp.full_name,
    'position', v_emp.position,
    'department', v_emp.department,
    'photo_url', v_emp.photo_url,
    'is_active', v_emp.is_active AND v_emp.employment_status = 'ACTIVE',
    'next_event', v_next_event
  );
END;
$$;

-- Atomic Employee Number Attendance Recording (Zero-delay alternating TIME_IN / TIME_OUT toggles in Asia/Manila)
CREATE OR REPLACE FUNCTION public.record_employee_number_attendance(
  p_employee_number text,
  p_pin text DEFAULT NULL,
  p_source text DEFAULT 'TERMINAL',
  p_device_info text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_emp public.employees%ROWTYPE;
  v_cred public.employee_number_credentials%ROWTYPE;
  v_sched public.schedules%ROWTYPE;
  v_settings public.company_settings%ROWTYPE;
  v_now timestamptz := now();
  v_manila_ts timestamp := (v_now AT TIME ZONE 'Asia/Manila');
  v_work_date date := (v_now AT TIME ZONE 'Asia/Manila')::date;
  v_att public.attendance%ROWTYPE;
  v_sched_in timestamptz;
  v_sched_out timestamptz;
  v_late_mins integer := 0;
  v_early_mins integer := 0;
  v_undertime_mins integer := 0;
  v_actual_hours numeric(5,2) := 0;
  v_regular_hours numeric(5,2) := 0;
  v_status public.attendance_status := 'PRESENT';
  v_holiday public.holidays%ROWTYPE;
  v_is_rest boolean := false;
  v_dow integer;
  v_day_class text := 'ORDINARY';
  v_session_count integer := 0;
  v_raw_hours numeric := 0;
BEGIN
  SELECT * INTO v_emp FROM public.employees WHERE upper(trim(employee_number)) = upper(trim(p_employee_number)) LIMIT 1;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error_code', 'UNKNOWN_EMPLOYEE', 'message', 'Employee Number not found.');
  END IF;

  IF NOT v_emp.is_active OR v_emp.employment_status <> 'ACTIVE' THEN
    RETURN jsonb_build_object('success', false, 'error_code', 'DEACTIVATED_EMPLOYEE', 'message', 'Employee account is inactive.');
  END IF;

  SELECT * INTO v_cred FROM public.employee_number_credentials WHERE employee_id = v_emp.id LIMIT 1;
  IF FOUND AND v_cred.credential_status <> 'ACTIVE' THEN
    RETURN jsonb_build_object('success', false, 'error_code', 'REVOKED_CREDENTIAL', 'message', 'Employee Number attendance credential is revoked or suspended.');
  END IF;

  IF FOUND AND v_cred.pin_required THEN
    IF p_pin IS NULL OR crypt(p_pin, v_cred.pin_hash) <> v_cred.pin_hash THEN
      RETURN jsonb_build_object('success', false, 'error_code', 'INVALID_PIN', 'message', 'Invalid attendance PIN for this Employee Number.');
    END IF;
  END IF;

  SELECT * INTO v_settings FROM public.company_settings LIMIT 1;
  SELECT * INTO v_sched FROM public.schedules WHERE id = COALESCE(v_emp.schedule_id, v_settings.default_schedule_id) LIMIT 1;

  -- Check overnight shift continuation if clocking out early morning for previous work_date
  IF v_sched.is_overnight AND (v_manila_ts::time < v_sched.time_in) THEN
    SELECT * INTO v_att FROM public.attendance
    WHERE employee_id = v_emp.id AND work_date = (v_work_date - 1) AND actual_time_in IS NOT NULL AND actual_time_out IS NULL
    LIMIT 1;
    IF FOUND THEN
      v_work_date := v_work_date - 1;
    END IF;
  END IF;

  v_sched_in := ((v_work_date::text || ' ' || COALESCE(v_sched.time_in, '08:00:00')::text)::timestamp AT TIME ZONE 'Asia/Manila');
  IF COALESCE(v_sched.is_overnight, false) THEN
    v_sched_out := (((v_work_date + 1)::text || ' ' || COALESCE(v_sched.time_out, '17:00:00')::text)::timestamp AT TIME ZONE 'Asia/Manila');
  ELSE
    v_sched_out := ((v_work_date::text || ' ' || COALESCE(v_sched.time_out, '17:00:00')::text)::timestamp AT TIME ZONE 'Asia/Manila');
  END IF;

  v_dow := EXTRACT(DOW FROM v_work_date)::integer;
  v_is_rest := v_dow = ANY(v_emp.rest_days);

  SELECT * INTO v_holiday FROM public.holidays WHERE holiday_date = v_work_date AND is_verified = true LIMIT 1;
  IF FOUND THEN
    IF v_holiday.holiday_type = 'REGULAR' THEN
      v_day_class := CASE WHEN v_is_rest THEN 'REGULAR_HOLIDAY_REST_DAY' ELSE 'REGULAR_HOLIDAY' END;
    ELSIF v_holiday.holiday_type = 'SPECIAL_NON_WORKING' THEN
      v_day_class := CASE WHEN v_is_rest THEN 'SPECIAL_HOLIDAY_REST_DAY' ELSE 'SPECIAL_HOLIDAY' END;
    END IF;
  ELSIF v_is_rest THEN
    v_day_class := 'REST_DAY';
  END IF;

  SELECT * INTO v_att FROM public.attendance WHERE employee_id = v_emp.id AND work_date = v_work_date FOR UPDATE;

  IF NOT FOUND THEN
    -- 1st punch of the workday: TIME IN
    IF v_now < v_sched_in THEN
      v_early_mins := FLOOR(EXTRACT(EPOCH FROM (v_sched_in - v_now)) / 60)::integer;
      v_status := 'ON_TIME';
    ELSIF v_now <= v_sched_in + make_interval(mins => COALESCE(v_sched.grace_period_minutes, 0)) THEN
      v_status := 'ON_TIME';
    ELSE
      v_late_mins := FLOOR(EXTRACT(EPOCH FROM (v_now - (v_sched_in + make_interval(mins => COALESCE(v_sched.grace_period_minutes, 0))))) / 60)::integer;
      v_status := CASE WHEN v_late_mins > 0 THEN 'LATE' ELSE 'ON_TIME' END;
    END IF;

    INSERT INTO public.attendance (
      employee_id, work_date, schedule_id, scheduled_time_in, scheduled_time_out,
      actual_time_in, early_arrival_minutes, late_minutes, status, day_classification, is_rest_day, holiday_id
    ) VALUES (
      v_emp.id, v_work_date, v_sched.id, v_sched_in, v_sched_out,
      v_now, v_early_mins, v_late_mins, v_status, v_day_class, v_is_rest, v_holiday.id
    ) RETURNING * INTO v_att;

    INSERT INTO public.attendance_events (attendance_id, employee_id, employee_number, event_type, recorded_at, work_date, source, device_info)
    VALUES (v_att.id, v_emp.id, v_emp.employee_number, 'TIME_IN', v_now, v_work_date, p_source, p_device_info);

    RETURN jsonb_build_object(
      'success', true,
      'event_type', 'TIME_IN',
      'employee_id', v_emp.id,
      'employee_number', v_emp.employee_number,
      'full_name', v_emp.full_name,
      'position', v_emp.position,
      'department', v_emp.department,
      'photo_url', v_emp.photo_url,
      'work_date', v_work_date,
      'recorded_at', v_now,
      'status', v_status,
      'late_minutes', v_late_mins
    );
  ELSIF v_att.actual_time_in IS NOT NULL AND v_att.actual_time_out IS NULL THEN
    -- Even punch (2nd, 4th, ...): TIME OUT
    INSERT INTO public.attendance_events (attendance_id, employee_id, employee_number, event_type, recorded_at, work_date, source, device_info)
    VALUES (v_att.id, v_emp.id, v_emp.employee_number, 'TIME_OUT', v_now, v_work_date, p_source, p_device_info);

    WITH paired AS (
      SELECT
        event_type,
        recorded_at,
        LEAD(recorded_at) OVER (ORDER BY recorded_at ASC) AS next_ts,
        LEAD(event_type) OVER (ORDER BY recorded_at ASC) AS next_type
      FROM public.attendance_events
      WHERE attendance_id = v_att.id
    )
    SELECT
      COUNT(*)::integer,
      COALESCE(SUM(EXTRACT(EPOCH FROM (next_ts - recorded_at)) / 3600.0), 0)
    INTO v_session_count, v_raw_hours
    FROM paired
    WHERE event_type = 'TIME_IN' AND next_type = 'TIME_OUT';

    IF v_session_count = 1 AND v_raw_hours > 4 THEN
      v_actual_hours := ROUND(GREATEST(0, v_raw_hours - (COALESCE(v_sched.lunch_break_minutes, 60) / 60.0))::numeric, 2);
    ELSE
      v_actual_hours := ROUND(GREATEST(0, v_raw_hours)::numeric, 2);
    END IF;

    v_regular_hours := LEAST(COALESCE(v_sched.regular_hours, 8.00), v_actual_hours);
    IF v_now < v_sched_out THEN
      v_undertime_mins := FLOOR(EXTRACT(EPOCH FROM (v_sched_out - v_now)) / 60)::integer;
    ELSE
      v_undertime_mins := 0;
    END IF;

    UPDATE public.attendance
    SET actual_time_out = v_now,
        undertime_minutes = v_undertime_mins,
        actual_hours = v_actual_hours,
        regular_hours = v_regular_hours,
        paid_hours = v_regular_hours + COALESCE(approved_overtime_hours, 0),
        updated_at = now()
    WHERE id = v_att.id;

    RETURN jsonb_build_object(
      'success', true,
      'event_type', 'TIME_OUT',
      'employee_id', v_emp.id,
      'employee_number', v_emp.employee_number,
      'full_name', v_emp.full_name,
      'position', v_emp.position,
      'department', v_emp.department,
      'photo_url', v_emp.photo_url,
      'work_date', v_work_date,
      'recorded_at', v_now,
      'status', v_att.status,
      'late_minutes', v_att.late_minutes,
      'undertime_minutes', v_undertime_mins
    );
  ELSE
    -- Odd subsequent punch (3rd, 5th, ...): Re-entry TIME IN
    UPDATE public.attendance
    SET actual_time_out = NULL,
        updated_at = now()
    WHERE id = v_att.id;

    INSERT INTO public.attendance_events (attendance_id, employee_id, employee_number, event_type, recorded_at, work_date, source, device_info)
    VALUES (v_att.id, v_emp.id, v_emp.employee_number, 'TIME_IN', v_now, v_work_date, p_source, p_device_info);

    RETURN jsonb_build_object(
      'success', true,
      'event_type', 'TIME_IN',
      'employee_id', v_emp.id,
      'employee_number', v_emp.employee_number,
      'full_name', v_emp.full_name,
      'position', v_emp.position,
      'department', v_emp.department,
      'photo_url', v_emp.photo_url,
      'work_date', v_work_date,
      'recorded_at', v_now,
      'status', v_att.status,
      'late_minutes', v_att.late_minutes
    );
  END IF;
END;
$$;

-- Enable RLS on ALL application tables
ALTER TABLE public.company_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.employee_number_credentials ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.employee_salary_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.employee_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.holidays ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance_corrections ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.overtime_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.leave_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payroll_periods ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payroll_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payroll_adjustments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.integration_sync_queue ENABLE ROW LEVEL SECURITY;

-- Policies: Profiles (Users read own profile; Super Admin/Admin manage; Users update only safe own fields, never role/permissions/employee_id)
CREATE POLICY profiles_select ON public.profiles FOR SELECT USING (
  id = auth.uid() OR public.current_user_role() IN ('SUPER_ADMIN', 'ADMIN', 'HR')
);
CREATE POLICY profiles_update_own ON public.profiles FOR UPDATE USING (id = auth.uid())
  WITH CHECK (
    id = auth.uid()
    AND role = (SELECT p.role FROM public.profiles p WHERE p.id = auth.uid())
    AND employee_id IS NOT DISTINCT FROM (SELECT p.employee_id FROM public.profiles p WHERE p.id = auth.uid())
    AND permissions = (SELECT p.permissions FROM public.profiles p WHERE p.id = auth.uid())
  );
CREATE POLICY profiles_super_admin_all ON public.profiles FOR ALL USING (
  public.current_user_role() = 'SUPER_ADMIN'
);

-- Policies: Company Settings & Schedules & Holidays
CREATE POLICY settings_read_all ON public.company_settings FOR SELECT TO authenticated USING (true);
CREATE POLICY settings_super_admin_write ON public.company_settings FOR ALL USING (public.current_user_role() = 'SUPER_ADMIN');

CREATE POLICY schedules_read_all ON public.schedules FOR SELECT TO authenticated USING (true);
CREATE POLICY schedules_admin_write ON public.schedules FOR ALL USING (public.current_user_role() IN ('SUPER_ADMIN', 'ADMIN'));

CREATE POLICY holidays_read_all ON public.holidays FOR SELECT TO authenticated USING (true);
CREATE POLICY holidays_manage ON public.holidays FOR ALL USING (
  public.current_user_role() = 'SUPER_ADMIN' OR public.has_permission('can_manage_holidays')
);

-- Policies: Employees (Employees only see own record; HR/Admin/Super Admin see employees)
CREATE POLICY employees_select ON public.employees FOR SELECT USING (
  id = public.current_employee_id() OR public.current_user_role() IN ('SUPER_ADMIN', 'ADMIN', 'HR')
);
CREATE POLICY employees_write ON public.employees FOR ALL USING (
  public.current_user_role() IN ('SUPER_ADMIN', 'ADMIN', 'HR')
);

-- Policies: Salary History & Employee Number Credentials
CREATE POLICY salary_history_select ON public.employee_salary_history FOR SELECT USING (
  public.current_user_role() = 'SUPER_ADMIN' OR public.has_permission('can_edit_salary')
);
CREATE POLICY salary_history_insert ON public.employee_salary_history FOR INSERT WITH CHECK (
  public.current_user_role() = 'SUPER_ADMIN' OR public.has_permission('can_edit_salary')
);

CREATE POLICY emp_creds_admin ON public.employee_number_credentials FOR ALL USING (
  public.current_user_role() IN ('SUPER_ADMIN', 'ADMIN')
);

-- Policies: Attendance, Events, Corrections
CREATE POLICY attendance_select ON public.attendance FOR SELECT USING (
  employee_id = public.current_employee_id() OR public.current_user_role() IN ('SUPER_ADMIN', 'ADMIN', 'HR')
);
CREATE POLICY attendance_admin_write ON public.attendance FOR ALL USING (
  public.current_user_role() IN ('SUPER_ADMIN', 'ADMIN')
);

CREATE POLICY attendance_events_select ON public.attendance_events FOR SELECT USING (
  employee_id = public.current_employee_id() OR public.current_user_role() IN ('SUPER_ADMIN', 'ADMIN', 'HR')
);

CREATE POLICY corrections_select ON public.attendance_corrections FOR SELECT USING (
  employee_id = public.current_employee_id() OR public.current_user_role() IN ('SUPER_ADMIN', 'ADMIN', 'HR')
);
CREATE POLICY corrections_insert ON public.attendance_corrections FOR INSERT WITH CHECK (
  public.current_user_role() IN ('SUPER_ADMIN', 'ADMIN')
);

-- Policies: Overtime & Leave
CREATE POLICY overtime_select ON public.overtime_requests FOR SELECT USING (
  employee_id = public.current_employee_id() OR public.current_user_role() IN ('SUPER_ADMIN', 'ADMIN', 'HR')
);
CREATE POLICY overtime_insert_own ON public.overtime_requests FOR INSERT WITH CHECK (
  employee_id = public.current_employee_id() OR public.current_user_role() IN ('SUPER_ADMIN', 'ADMIN')
);
CREATE POLICY overtime_admin_update ON public.overtime_requests FOR UPDATE USING (
  public.current_user_role() IN ('SUPER_ADMIN', 'ADMIN')
);

CREATE POLICY leave_select ON public.leave_requests FOR SELECT USING (
  employee_id = public.current_employee_id() OR public.current_user_role() IN ('SUPER_ADMIN', 'ADMIN', 'HR')
);
CREATE POLICY leave_insert_own ON public.leave_requests FOR INSERT WITH CHECK (
  employee_id = public.current_employee_id() OR public.current_user_role() IN ('SUPER_ADMIN', 'ADMIN', 'HR')
);
CREATE POLICY leave_admin_update ON public.leave_requests FOR UPDATE USING (
  public.current_user_role() IN ('SUPER_ADMIN', 'ADMIN', 'HR')
);

-- Policies: Payroll (Sensitive! Employees see ONLY their own finalized/paid payslips; Admins require permission)
CREATE POLICY payroll_periods_select ON public.payroll_periods FOR SELECT USING (
  public.current_user_role() = 'SUPER_ADMIN'
  OR public.has_permission('can_manage_payroll')
  OR (status IN ('FINALIZED', 'PAID') AND public.current_employee_id() IS NOT NULL)
);
CREATE POLICY payroll_periods_write ON public.payroll_periods FOR ALL USING (
  public.current_user_role() = 'SUPER_ADMIN' OR public.has_permission('can_manage_payroll')
);

CREATE POLICY payroll_records_select ON public.payroll_records FOR SELECT USING (
  public.current_user_role() = 'SUPER_ADMIN'
  OR public.has_permission('can_manage_payroll')
  OR (employee_id = public.current_employee_id() AND EXISTS (
    SELECT 1 FROM public.payroll_periods pp WHERE pp.id = payroll_period_id AND pp.status IN ('FINALIZED', 'PAID')
  ))
);
CREATE POLICY payroll_records_write ON public.payroll_records FOR ALL USING (
  public.current_user_role() = 'SUPER_ADMIN' OR public.has_permission('can_manage_payroll')
);

CREATE POLICY payroll_adjustments_manage ON public.payroll_adjustments FOR ALL USING (
  public.current_user_role() = 'SUPER_ADMIN' OR public.has_permission('can_manage_payroll')
);

-- Policies: Audit Logs & Integration Queue
CREATE POLICY audit_logs_select ON public.audit_logs FOR SELECT USING (
  public.current_user_role() IN ('SUPER_ADMIN', 'ADMIN')
);
CREATE POLICY audit_logs_insert ON public.audit_logs FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY integration_queue_super ON public.integration_sync_queue FOR ALL USING (
  public.current_user_role() = 'SUPER_ADMIN'
);
