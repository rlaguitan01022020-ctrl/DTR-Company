-- 0005_theme_and_deductions.sql
-- Adds Light/Dark theme setting, payslip note, and itemized PH statutory/loan/coop deductions with remarks

ALTER TABLE public.company_settings
  ADD COLUMN IF NOT EXISTS theme text NOT NULL DEFAULT 'light' CHECK (theme IN ('light', 'dark')),
  ADD COLUMN IF NOT EXISTS payslip_note text DEFAULT 'DEDUCTION ON SSS & PHIC SHARE';

ALTER TABLE public.employees
  ADD COLUMN IF NOT EXISTS sss_share numeric(12,2) NOT NULL DEFAULT 0 CHECK (sss_share >= 0),
  ADD COLUMN IF NOT EXISTS sss_share_remarks text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS phic_share numeric(12,2) NOT NULL DEFAULT 0 CHECK (phic_share >= 0),
  ADD COLUMN IF NOT EXISTS phic_share_remarks text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS pagibig_share numeric(12,2) NOT NULL DEFAULT 0 CHECK (pagibig_share >= 0),
  ADD COLUMN IF NOT EXISTS sss_loan numeric(12,2) NOT NULL DEFAULT 0 CHECK (sss_loan >= 0),
  ADD COLUMN IF NOT EXISTS pagibig_loan numeric(12,2) NOT NULL DEFAULT 0 CHECK (pagibig_loan >= 0),
  ADD COLUMN IF NOT EXISTS coop_share numeric(12,2) NOT NULL DEFAULT 0 CHECK (coop_share >= 0),
  ADD COLUMN IF NOT EXISTS coop_loan numeric(12,2) NOT NULL DEFAULT 0 CHECK (coop_loan >= 0),
  ADD COLUMN IF NOT EXISTS donation numeric(12,2) NOT NULL DEFAULT 0 CHECK (donation >= 0),
  ADD COLUMN IF NOT EXISTS cash_advance numeric(12,2) NOT NULL DEFAULT 0 CHECK (cash_advance >= 0);

ALTER TABLE public.employee_salary_history
  ADD COLUMN IF NOT EXISTS deductions_snapshot jsonb;
