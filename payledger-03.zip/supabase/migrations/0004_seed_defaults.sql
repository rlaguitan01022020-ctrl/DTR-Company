-- 0004_seed_defaults.sql
-- Seed default schedule (8:00 AM - 5:00 PM, 1h unpaid lunch, 0m grace, Asia/Manila), company settings, and Philippine holidays

WITH default_sched AS (
  INSERT INTO public.schedules (name, time_in, time_out, lunch_break_minutes, grace_period_minutes, regular_hours, is_flexible, is_overnight, is_default)
  SELECT 'Standard Day Shift (8:00 AM - 5:00 PM)', '08:00:00', '17:00:00', 60, 0, 8.00, false, false, true
  WHERE NOT EXISTS (SELECT 1 FROM public.schedules WHERE is_default = true)
  RETURNING id
)
INSERT INTO public.company_settings (
  company_name, company_address, contact_number, company_email, timezone,
  working_days, default_schedule_id, default_time_in, default_time_out,
  lunch_break_minutes, grace_period_minutes, regular_working_hours, default_rest_days
)
SELECT
  'PayLedger PH Enterprise',
  'Ayala Avenue, Makati City, Metro Manila 1226',
  '+63 2 8855 4200',
  'hr@payledger.ph',
  'Asia/Manila',
  ARRAY[1,2,3,4,5,6],
  (SELECT id FROM default_sched),
  '08:00:00',
  '17:00:00',
  60,
  0,
  8.00,
  ARRAY[0]
WHERE NOT EXISTS (SELECT 1 FROM public.company_settings);

-- Official Philippine Holidays (2026)
INSERT INTO public.holidays (holiday_date, name, holiday_type, description, is_verified, source)
VALUES
  ('2026-01-01', 'New Year''s Day', 'REGULAR', 'Official Regular Holiday under Philippine Labor Code', true, 'OFFICIAL_PH'),
  ('2026-02-17', 'Chinese New Year', 'SPECIAL_NON_WORKING', 'Special Non-Working Holiday', true, 'OFFICIAL_PH'),
  ('2026-02-25', 'EDSA People Power Revolution Anniversary', 'SPECIAL_NON_WORKING', 'Special Non-Working Holiday', true, 'OFFICIAL_PH'),
  ('2026-04-02', 'Maundy Thursday', 'REGULAR', 'Official Regular Holiday', true, 'OFFICIAL_PH'),
  ('2026-04-03', 'Good Friday', 'REGULAR', 'Official Regular Holiday', true, 'OFFICIAL_PH'),
  ('2026-04-04', 'Black Saturday', 'SPECIAL_NON_WORKING', 'Special Non-Working Holiday', true, 'OFFICIAL_PH'),
  ('2026-04-09', 'Araw ng Kagitingan (Day of Valor)', 'REGULAR', 'Official Regular Holiday', true, 'OFFICIAL_PH'),
  ('2026-05-01', 'Labor Day', 'REGULAR', 'Official Regular Holiday', true, 'OFFICIAL_PH'),
  ('2026-06-12', 'Independence Day', 'REGULAR', 'Official Regular Holiday', true, 'OFFICIAL_PH'),
  ('2026-08-21', 'Ninoy Aquino Day', 'SPECIAL_NON_WORKING', 'Special Non-Working Holiday', true, 'OFFICIAL_PH'),
  ('2026-08-31', 'National Heroes Day', 'REGULAR', 'Last Monday of August — Official Regular Holiday', true, 'OFFICIAL_PH'),
  ('2026-11-01', 'All Saints'' Day', 'SPECIAL_NON_WORKING', 'Special Non-Working Holiday', true, 'OFFICIAL_PH'),
  ('2026-11-30', 'Bonifacio Day', 'REGULAR', 'Official Regular Holiday', true, 'OFFICIAL_PH'),
  ('2026-12-08', 'Feast of the Immaculate Conception', 'SPECIAL_NON_WORKING', 'Special Non-Working Holiday', true, 'OFFICIAL_PH'),
  ('2026-12-25', 'Christmas Day', 'REGULAR', 'Official Regular Holiday', true, 'OFFICIAL_PH'),
  ('2026-12-30', 'Rizal Day', 'REGULAR', 'Official Regular Holiday', true, 'OFFICIAL_PH'),
  ('2026-12-31', 'Last Day of the Year', 'SPECIAL_NON_WORKING', 'Special Non-Working Holiday', true, 'OFFICIAL_PH')
ON CONFLICT (holiday_date, name) DO NOTHING;
