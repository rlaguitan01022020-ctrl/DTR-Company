-- 0001_initial_schema.sql
-- PayLedger PH: Employee Management, Employee Number Attendance, DTR, Overtime, Holiday Pay & Payroll Schema
-- Timezone standard: Asia/Manila | Currency: PHP (₱)

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Enum types
DO $$ BEGIN
  CREATE TYPE public.user_role AS ENUM ('SUPER_ADMIN', 'ADMIN', 'HR', 'EMPLOYEE');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.employment_type AS ENUM ('REGULAR', 'PROBATIONARY', 'CONTRACTUAL', 'PART_TIME');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.employment_status AS ENUM ('ACTIVE', 'INACTIVE', 'RESIGNED', 'TERMINATED');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.salary_type AS ENUM ('DAILY', 'HOURLY', 'MONTHLY');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.attendance_status AS ENUM (
    'PRESENT', 'ON_TIME', 'LATE', 'OVERTIME', 'ABSENT', 'LEAVE', 'REST_DAY', 'HOLIDAY', 'INCOMPLETE'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.overtime_status AS ENUM ('PENDING', 'APPROVED', 'REJECTED', 'DECLINED_BY_EMPLOYEE');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.leave_status AS ENUM ('PENDING', 'APPROVED', 'REJECTED', 'CANCELLED');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.holiday_type AS ENUM ('REGULAR', 'SPECIAL_NON_WORKING', 'SPECIAL_WORKING');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.payroll_status AS ENUM ('DRAFT', 'FOR_REVIEW', 'APPROVED', 'FINALIZED', 'PAID');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.credential_status AS ENUM ('ACTIVE', 'SUSPENDED', 'REVOKED');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.sync_status AS ENUM ('PENDING', 'SYNCED', 'FAILED');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- 1. Schedules
CREATE TABLE IF NOT EXISTS public.schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  time_in time NOT NULL DEFAULT '08:00:00',
  time_out time NOT NULL DEFAULT '17:00:00',
  lunch_break_minutes integer NOT NULL DEFAULT 60 CHECK (lunch_break_minutes >= 0 AND lunch_break_minutes <= 180),
  grace_period_minutes integer NOT NULL DEFAULT 0 CHECK (grace_period_minutes >= 0 AND grace_period_minutes <= 120),
  regular_hours numeric(5,2) NOT NULL DEFAULT 8.00 CHECK (regular_hours > 0 AND regular_hours <= 24),
  is_flexible boolean NOT NULL DEFAULT false,
  is_overnight boolean NOT NULL DEFAULT false,
  is_default boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 2. Company Settings
CREATE TABLE IF NOT EXISTS public.company_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL DEFAULT 'PayLedger PH Demo Corp.',
  company_logo_url text,
  company_address text NOT NULL DEFAULT 'Makati City, Metro Manila, Philippines',
  contact_number text NOT NULL DEFAULT '+63 2 8888 0000',
  company_email text NOT NULL DEFAULT 'hr@company.ph',
  timezone text NOT NULL DEFAULT 'Asia/Manila',
  working_days integer[] NOT NULL DEFAULT ARRAY[1,2,3,4,5,6],
  default_schedule_id uuid REFERENCES public.schedules(id) ON DELETE SET NULL,
  default_time_in time NOT NULL DEFAULT '08:00:00',
  default_time_out time NOT NULL DEFAULT '17:00:00',
  lunch_break_minutes integer NOT NULL DEFAULT 60,
  grace_period_minutes integer NOT NULL DEFAULT 0,
  regular_working_hours numeric(5,2) NOT NULL DEFAULT 8.00,
  default_rest_days integer[] NOT NULL DEFAULT ARRAY[0],
  payroll_schedule text NOT NULL DEFAULT 'SEMI_MONTHLY',
  employee_number_prefix text NOT NULL DEFAULT 'EMP',
  require_kiosk_pin boolean NOT NULL DEFAULT false,
  multipliers jsonb NOT NULL DEFAULT '{
    "ordinary": {"first8": 1.00, "overtime": 1.25},
    "rest_day": {"first8": 1.30, "overtime": 1.69},
    "special_holiday": {"first8": 1.30, "overtime": 1.69},
    "special_holiday_rest_day": {"first8": 1.50, "overtime": 1.95},
    "regular_holiday": {"first8": 2.00, "overtime": 2.60},
    "regular_holiday_rest_day": {"first8": 2.60, "overtime": 3.38}
  }'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 3. Employees
CREATE TABLE IF NOT EXISTS public.employees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_number text NOT NULL UNIQUE,
  full_name text NOT NULL,
  photo_url text,
  position text NOT NULL,
  department text NOT NULL,
  contact_number text,
  address text,
  email text,
  date_hired date NOT NULL DEFAULT CURRENT_DATE,
  employment_type public.employment_type NOT NULL DEFAULT 'REGULAR',
  employment_status public.employment_status NOT NULL DEFAULT 'ACTIVE',
  schedule_id uuid REFERENCES public.schedules(id) ON DELETE SET NULL,
  rest_days integer[] NOT NULL DEFAULT ARRAY[0],
  salary_type public.salary_type NOT NULL DEFAULT 'DAILY',
  daily_rate numeric(12,2) NOT NULL DEFAULT 0 CHECK (daily_rate >= 0),
  hourly_rate numeric(12,2) NOT NULL DEFAULT 0 CHECK (hourly_rate >= 0),
  monthly_rate numeric(12,2) NOT NULL DEFAULT 0 CHECK (monthly_rate >= 0),
  overtime_rate numeric(12,2) NOT NULL DEFAULT 0 CHECK (overtime_rate >= 0),
  meal_allowance numeric(12,2) NOT NULL DEFAULT 0 CHECK (meal_allowance >= 0),
  transport_allowance numeric(12,2) NOT NULL DEFAULT 0 CHECK (transport_allowance >= 0),
  other_allowances numeric(12,2) NOT NULL DEFAULT 0 CHECK (other_allowances >= 0),
  default_deductions numeric(12,2) NOT NULL DEFAULT 0 CHECK (default_deductions >= 0),
  is_active boolean NOT NULL DEFAULT true,
  deactivated_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_employees_number ON public.employees(employee_number);
CREATE INDEX IF NOT EXISTS idx_employees_department ON public.employees(department);
CREATE INDEX IF NOT EXISTS idx_employees_active ON public.employees(is_active);

-- 4. User Profiles (All user profile data stored in Supabase database; no Google OAuth)
CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL UNIQUE,
  full_name text NOT NULL,
  avatar_url text,
  phone text,
  address text,
  department text,
  position text,
  role public.user_role NOT NULL DEFAULT 'EMPLOYEE',
  employee_id uuid UNIQUE REFERENCES public.employees(id) ON DELETE SET NULL,
  employee_number text,
  permissions jsonb NOT NULL DEFAULT '{
    "can_edit_salary": false,
    "can_manage_payroll": false,
    "can_manage_holidays": false,
    "can_view_reports": false
  }'::jsonb,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_profiles_role ON public.profiles(role);
CREATE INDEX IF NOT EXISTS idx_profiles_employee_id ON public.profiles(employee_id);

-- 5. Employee Number Attendance Credentials (replaces QR credentials)
CREATE TABLE IF NOT EXISTS public.employee_number_credentials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid NOT NULL UNIQUE REFERENCES public.employees(id) ON DELETE CASCADE,
  employee_number text NOT NULL UNIQUE,
  credential_status public.credential_status NOT NULL DEFAULT 'ACTIVE',
  pin_required boolean NOT NULL DEFAULT false,
  pin_hash text,
  issued_at timestamptz NOT NULL DEFAULT now(),
  revoked_at timestamptz,
  revoked_reason text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 6. Effective-Dated Salary History
CREATE TABLE IF NOT EXISTS public.employee_salary_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  salary_type public.salary_type NOT NULL,
  previous_daily_rate numeric(12,2) NOT NULL DEFAULT 0,
  new_daily_rate numeric(12,2) NOT NULL DEFAULT 0,
  previous_hourly_rate numeric(12,2) NOT NULL DEFAULT 0,
  new_hourly_rate numeric(12,2) NOT NULL DEFAULT 0,
  previous_monthly_rate numeric(12,2) NOT NULL DEFAULT 0,
  new_monthly_rate numeric(12,2) NOT NULL DEFAULT 0,
  previous_overtime_rate numeric(12,2) NOT NULL DEFAULT 0,
  new_overtime_rate numeric(12,2) NOT NULL DEFAULT 0,
  previous_allowances numeric(12,2) NOT NULL DEFAULT 0,
  new_allowances numeric(12,2) NOT NULL DEFAULT 0,
  previous_deductions numeric(12,2) NOT NULL DEFAULT 0,
  new_deductions numeric(12,2) NOT NULL DEFAULT 0,
  effective_date date NOT NULL DEFAULT CURRENT_DATE,
  reason text NOT NULL,
  changed_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_salary_history_emp_date ON public.employee_salary_history(employee_id, effective_date DESC);

-- 7. Employee Schedule Assignments
CREATE TABLE IF NOT EXISTS public.employee_schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  schedule_id uuid NOT NULL REFERENCES public.schedules(id) ON DELETE RESTRICT,
  rest_days integer[] NOT NULL DEFAULT ARRAY[0],
  effective_date date NOT NULL DEFAULT CURRENT_DATE,
  assigned_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 8. Holidays
CREATE TABLE IF NOT EXISTS public.holidays (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  holiday_date date NOT NULL,
  name text NOT NULL,
  holiday_type public.holiday_type NOT NULL,
  description text,
  is_verified boolean NOT NULL DEFAULT true,
  source text DEFAULT 'MANUAL',
  created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (holiday_date, name)
);

CREATE INDEX IF NOT EXISTS idx_holidays_date ON public.holidays(holiday_date);

-- 9. Attendance Summary (one record per employee per work_date)
CREATE TABLE IF NOT EXISTS public.attendance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  work_date date NOT NULL,
  schedule_id uuid REFERENCES public.schedules(id) ON DELETE SET NULL,
  scheduled_time_in timestamptz,
  scheduled_time_out timestamptz,
  actual_time_in timestamptz,
  actual_time_out timestamptz,
  early_arrival_minutes integer NOT NULL DEFAULT 0 CHECK (early_arrival_minutes >= 0),
  late_minutes integer NOT NULL DEFAULT 0 CHECK (late_minutes >= 0),
  undertime_minutes integer NOT NULL DEFAULT 0 CHECK (undertime_minutes >= 0),
  regular_hours numeric(5,2) NOT NULL DEFAULT 0 CHECK (regular_hours >= 0),
  actual_hours numeric(5,2) NOT NULL DEFAULT 0 CHECK (actual_hours >= 0),
  paid_hours numeric(5,2) NOT NULL DEFAULT 0 CHECK (paid_hours >= 0),
  approved_overtime_hours numeric(5,2) NOT NULL DEFAULT 0 CHECK (approved_overtime_hours >= 0),
  status public.attendance_status NOT NULL DEFAULT 'INCOMPLETE',
  day_classification text NOT NULL DEFAULT 'ORDINARY',
  is_rest_day boolean NOT NULL DEFAULT false,
  holiday_id uuid REFERENCES public.holidays(id) ON DELETE SET NULL,
  is_corrected boolean NOT NULL DEFAULT false,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (employee_id, work_date)
);

CREATE INDEX IF NOT EXISTS idx_attendance_work_date ON public.attendance(work_date DESC);
CREATE INDEX IF NOT EXISTS idx_attendance_emp_date ON public.attendance(employee_id, work_date DESC);

-- 10. Immutable Attendance Events (punch history)
CREATE TABLE IF NOT EXISTS public.attendance_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  attendance_id uuid NOT NULL REFERENCES public.attendance(id) ON DELETE CASCADE,
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  employee_number text NOT NULL,
  event_type text NOT NULL CHECK (event_type IN ('TIME_IN', 'TIME_OUT')),
  recorded_at timestamptz NOT NULL DEFAULT now(),
  work_date date NOT NULL,
  source text NOT NULL DEFAULT 'TERMINAL',
  device_info text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_attendance_events_emp_time ON public.attendance_events(employee_id, recorded_at DESC);

-- 11. Attendance Corrections (traceable audit history)
CREATE TABLE IF NOT EXISTS public.attendance_corrections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  attendance_id uuid NOT NULL REFERENCES public.attendance(id) ON DELETE CASCADE,
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  work_date date NOT NULL,
  original_values jsonb NOT NULL,
  corrected_values jsonb NOT NULL,
  reason text NOT NULL,
  corrected_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 12. Overtime Requests
CREATE TABLE IF NOT EXISTS public.overtime_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  attendance_id uuid REFERENCES public.attendance(id) ON DELETE SET NULL,
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  work_date date NOT NULL,
  scheduled_time_in timestamptz,
  actual_time_in timestamptz,
  scheduled_time_out timestamptz,
  actual_time_out timestamptz,
  decision text NOT NULL CHECK (decision IN ('YES', 'NO')),
  requested_hours numeric(5,2) NOT NULL DEFAULT 0 CHECK (requested_hours >= 0),
  verified_hours numeric(5,2) NOT NULL DEFAULT 0 CHECK (verified_hours >= 0),
  approved_hours numeric(5,2) NOT NULL DEFAULT 0 CHECK (approved_hours >= 0),
  overtime_rate_applied numeric(12,2) NOT NULL DEFAULT 0,
  approved_amount numeric(12,2) NOT NULL DEFAULT 0,
  reason text,
  status public.overtime_status NOT NULL DEFAULT 'PENDING',
  admin_remarks text,
  reviewed_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_overtime_emp_date ON public.overtime_requests(employee_id, work_date DESC);

-- 13. Leave Requests
CREATE TABLE IF NOT EXISTS public.leave_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  leave_type text NOT NULL,
  start_date date NOT NULL,
  end_date date NOT NULL,
  total_days numeric(5,2) NOT NULL CHECK (total_days > 0),
  is_paid boolean NOT NULL DEFAULT true,
  reason text NOT NULL,
  attachment_path text,
  status public.leave_status NOT NULL DEFAULT 'PENDING',
  admin_remarks text,
  reviewed_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (end_date >= start_date)
);

-- 14. Payroll Periods
CREATE TABLE IF NOT EXISTS public.payroll_periods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  period_name text NOT NULL,
  start_date date NOT NULL,
  end_date date NOT NULL,
  pay_date date NOT NULL,
  payroll_schedule text NOT NULL DEFAULT 'SEMI_MONTHLY',
  status public.payroll_status NOT NULL DEFAULT 'DRAFT',
  generated_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  approved_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  finalized_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  finalized_at timestamptz,
  paid_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (end_date >= start_date)
);

-- 15. Payroll Records (Snapshots locked upon finalization)
CREATE TABLE IF NOT EXISTS public.payroll_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  payroll_period_id uuid NOT NULL REFERENCES public.payroll_periods(id) ON DELETE CASCADE,
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE RESTRICT,
  employee_number text NOT NULL,
  employee_name text NOT NULL,
  department text NOT NULL,
  position text NOT NULL,
  salary_type public.salary_type NOT NULL,
  rate_snapshot jsonb NOT NULL,
  multipliers_snapshot jsonb NOT NULL,
  days_worked numeric(6,2) NOT NULL DEFAULT 0,
  regular_hours numeric(8,2) NOT NULL DEFAULT 0,
  approved_overtime_hours numeric(8,2) NOT NULL DEFAULT 0,
  basic_pay numeric(12,2) NOT NULL DEFAULT 0,
  regular_workday_pay numeric(12,2) NOT NULL DEFAULT 0,
  rest_day_pay numeric(12,2) NOT NULL DEFAULT 0,
  special_holiday_pay numeric(12,2) NOT NULL DEFAULT 0,
  regular_holiday_pay numeric(12,2) NOT NULL DEFAULT 0,
  holiday_rest_day_pay numeric(12,2) NOT NULL DEFAULT 0,
  regular_overtime_pay numeric(12,2) NOT NULL DEFAULT 0,
  rest_day_overtime_pay numeric(12,2) NOT NULL DEFAULT 0,
  holiday_overtime_pay numeric(12,2) NOT NULL DEFAULT 0,
  allowances_total numeric(12,2) NOT NULL DEFAULT 0,
  absence_deductions numeric(12,2) NOT NULL DEFAULT 0,
  undertime_deductions numeric(12,2) NOT NULL DEFAULT 0,
  other_deductions numeric(12,2) NOT NULL DEFAULT 0,
  adjustments_total numeric(12,2) NOT NULL DEFAULT 0,
  gross_pay numeric(12,2) NOT NULL DEFAULT 0,
  net_pay numeric(12,2) NOT NULL DEFAULT 0,
  attendance_refs jsonb NOT NULL DEFAULT '[]'::jsonb,
  overtime_refs jsonb NOT NULL DEFAULT '[]'::jsonb,
  is_locked boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (payroll_period_id, employee_id)
);

-- 16. Payroll Adjustments
CREATE TABLE IF NOT EXISTS public.payroll_adjustments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  payroll_record_id uuid NOT NULL REFERENCES public.payroll_records(id) ON DELETE CASCADE,
  payroll_period_id uuid NOT NULL REFERENCES public.payroll_periods(id) ON DELETE CASCADE,
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE RESTRICT,
  adjustment_type text NOT NULL CHECK (adjustment_type IN ('ADDITION', 'DEDUCTION')),
  category text NOT NULL,
  amount numeric(12,2) NOT NULL CHECK (amount >= 0),
  reason text NOT NULL,
  created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 17. Audit Logs (append-only)
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_user_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  actor_role text,
  action text NOT NULL,
  table_name text NOT NULL,
  record_id text,
  previous_value jsonb,
  new_value jsonb,
  reason text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_created ON public.audit_logs(created_at DESC);

-- 18. Optional Integration Sync Queue (e.g., Google Sheets)
CREATE TABLE IF NOT EXISTS public.integration_sync_queue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider text NOT NULL DEFAULT 'GOOGLE_SHEETS',
  sheet_tab text NOT NULL,
  record_type text NOT NULL,
  record_id text NOT NULL,
  idempotency_key text NOT NULL UNIQUE,
  payload jsonb NOT NULL,
  status public.sync_status NOT NULL DEFAULT 'PENDING',
  retry_count integer NOT NULL DEFAULT 0,
  last_error text,
  synced_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
