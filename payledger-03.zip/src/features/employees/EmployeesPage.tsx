import React, { useMemo, useState } from 'react';
import { Search, Edit2, Archive, RotateCcw, CreditCard, Upload } from 'lucide-react';
import { Avatar, ConfirmDialog, EmptyState, StatusLabel } from '../../components/ui/Common';
import { formatManilaDate, formatPeso } from '../../lib/date/manila';
import { dataService } from '../../services/dataService';
import type { Employee, Schedule, UserProfile } from '../../types/database';

const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export function EmployeesPage({
  actor,
  employees,
  schedules,
  onReload,
  onOpenIdCard,
  onOpenRegister,
  onNotify,
}: {
  actor: UserProfile;
  employees: Employee[];
  schedules: Schedule[];
  onReload: () => void;
  onOpenIdCard: (empId: string) => void;
  onOpenRegister: () => void;
  onNotify: (type: 'success' | 'error', title: string, desc?: string) => void;
}) {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ACTIVE' | 'INACTIVE' | 'ALL'>('ACTIVE');
  const [editing, setEditing] = useState<Employee | null>(null);
  const [confirmToggle, setConfirmToggle] = useState<Employee | null>(null);
  const [saving, setSaving] = useState(false);

  const canSeeSalary = actor.role === 'SUPER_ADMIN' || actor.permissions.can_edit_salary;

  const filtered = useMemo(() => {
    return employees.filter((e) => {
      if (statusFilter === 'ACTIVE' && !e.is_active) return false;
      if (statusFilter === 'INACTIVE' && e.is_active) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        return (
          e.full_name.toLowerCase().includes(q) ||
          e.employee_number.toLowerCase().includes(q) ||
          e.department.toLowerCase().includes(q) ||
          e.position.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [employees, statusFilter, search]);

  async function handleSaveEdit(e: React.FormEvent) {
    e.preventDefault();
    if (!editing) return;
    setSaving(true);
    try {
      await dataService.updateEmployee(actor, editing.id, {
        employee_number: editing.employee_number.trim().toUpperCase(),
        full_name: editing.full_name,
        position: editing.position,
        department: editing.department,
        contact_number: editing.contact_number,
        address: editing.address,
        email: editing.email,
        schedule_id: editing.schedule_id,
        rest_days: editing.rest_days,
        employment_type: editing.employment_type,
      });
      onNotify('success', 'Employee Updated', `${editing.full_name} saved.`);
      setEditing(null);
      onReload();
    } catch (err) {
      onNotify('error', 'Update failed', (err as Error).message);
    } finally {
      setSaving(false);
    }
  }

  async function handlePhotoUpload(emp: Employee, file: File) {
    try {
      const url = await dataService.uploadEmployeePhoto(emp.id, file);
      await dataService.updateEmployee(actor, emp.id, { photo_url: url });
      onNotify('success', 'Photo Updated', `Updated photo for ${emp.full_name}.`);
      onReload();
    } catch (err) {
      onNotify('error', 'Upload failed', (err as Error).message);
    }
  }

  async function handleToggleActive(emp: Employee) {
    try {
      const nextActive = !emp.is_active;
      await dataService.updateEmployee(actor, emp.id, {
        is_active: nextActive,
        employment_status: nextActive ? 'ACTIVE' : 'INACTIVE',
        deactivated_at: nextActive ? null : new Date().toISOString(),
      });
      onNotify(
        'success',
        nextActive ? 'Employee Restored' : 'Employee Deactivated',
        `${emp.full_name} (${emp.employee_number}) status updated.`
      );
      setConfirmToggle(null);
      onReload();
    } catch (err) {
      onNotify('error', 'Status update failed', (err as Error).message);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">Employee Management</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Historical attendance and payroll records are preserved; use deactivation instead of permanent deletion.
          </p>
        </div>
        {actor.role === 'SUPER_ADMIN' || actor.role === 'ADMIN' ? (
          <button
            type="button"
            onClick={onOpenRegister}
            className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
          >
            + Register Employee
          </button>
        ) : null}
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-sm dark:shadow-lg dark:shadow-black/30 rounded-lg p-4 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="relative flex-1 min-w-[220px] max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search name, Employee Number, department..."
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-2xs"
            />
          </div>
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg">
            {(['ACTIVE', 'INACTIVE', 'ALL'] as const).map((tab) => (
              <button
                key={tab}
                type="button"
                onClick={() => setStatusFilter(tab)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                  statusFilter === tab
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                }`}
              >
                {tab === 'ACTIVE' ? 'Active' : tab === 'INACTIVE' ? 'Archived' : 'All'}
              </button>
            ))}
          </div>
        </div>

        {filtered.length === 0 ? (
          <EmptyState
            title="No employees found"
            description="Register a new employee or change your filter criteria."
          />
        ) : (
          <div className="overflow-x-auto border border-slate-200 dark:border-slate-700 rounded-lg shadow-sm dark:shadow-lg dark:shadow-black/30">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/90 border-b border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 font-semibold shadow-2xs">
                  <th className="py-2.5 px-3 border-r border-slate-200 dark:border-slate-700">Employee</th>
                  <th className="py-2.5 px-3 border-r border-slate-200 dark:border-slate-700">Department &amp; Role</th>
                  <th className="py-2.5 px-3 border-r border-slate-200 dark:border-slate-700">Schedule</th>
                  <th className="py-2.5 px-3 border-r border-slate-200 dark:border-slate-700">Rest Day(s)</th>
                  {canSeeSalary && (
                    <th className="py-2.5 px-3 text-right border-r border-slate-200 dark:border-slate-700">Base Rate</th>
                  )}
                  <th className="py-2.5 px-3 border-r border-slate-200 dark:border-slate-700">Status</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700 text-xs">
                {filtered.map((emp) => {
                  const sched = schedules.find((s) => s.id === emp.schedule_id);
                  return (
                    <tr
                      key={emp.id}
                      className="hover:bg-slate-50/90 dark:hover:bg-slate-800/70 shadow-[0_1px_3px_rgba(15,23,42,0.04)] dark:shadow-[0_1px_3px_rgba(0,0,0,0.35)]"
                    >
                      <td className="py-3 px-3 border-r border-slate-200 dark:border-slate-700">
                        <div className="flex items-center gap-2.5">
                          <Avatar name={emp.full_name} src={emp.photo_url} size="md" />
                          <div>
                            <p className="font-semibold text-slate-900 dark:text-slate-100">{emp.full_name}</p>
                            <p className="text-slate-500 dark:text-slate-400 font-mono">
                              {emp.employee_number} · Hired {formatManilaDate(emp.date_hired)}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-3 border-r border-slate-200 dark:border-slate-700">
                        <p className="font-medium text-slate-900 dark:text-slate-100">{emp.position}</p>
                        <p className="text-slate-500 dark:text-slate-400">
                          {emp.department} · {emp.employment_type}
                        </p>
                      </td>
                      <td className="py-3 px-3 text-slate-700 dark:text-slate-300 border-r border-slate-200 dark:border-slate-700">
                        {sched?.name ?? 'Default 8-5'}
                      </td>
                      <td className="py-3 px-3 font-mono text-slate-700 dark:text-slate-300 border-r border-slate-200 dark:border-slate-700">
                        {emp.rest_days.map((d) => DAY_NAMES[d]).join(', ') || 'None'}
                      </td>
                      {canSeeSalary && (
                        <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-900 dark:text-slate-100 border-r border-slate-200 dark:border-slate-700">
                          {emp.salary_type === 'MONTHLY'
                            ? `${formatPeso(emp.monthly_rate)}/mo`
                            : emp.salary_type === 'HOURLY'
                            ? `${formatPeso(emp.hourly_rate)}/hr`
                            : `${formatPeso(emp.daily_rate)}/day`}
                        </td>
                      )}
                      <td className="py-3 px-3 border-r border-slate-200 dark:border-slate-700">
                        <StatusLabel label={emp.is_active ? 'ACTIVE' : 'INACTIVE'} />
                      </td>
                      <td className="py-3 px-3">
                        <div className="flex items-center justify-end gap-1.5">
                          <label
                            title="Upload Photo"
                            className="p-1.5 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded cursor-pointer"
                          >
                            <Upload className="w-3.5 h-3.5" />
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={(e) => {
                                const f = e.target.files?.[0];
                                if (f) handlePhotoUpload(emp, f);
                              }}
                            />
                          </label>
                          <button
                            type="button"
                            onClick={() => onOpenIdCard(emp.id)}
                            title="Employee ID Card"
                            className="p-1.5 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/60 rounded"
                          >
                            <CreditCard className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditing({ ...emp })}
                            title="Edit Employee"
                            className="p-1.5 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmToggle(emp)}
                            title={emp.is_active ? 'Deactivate Employee' : 'Restore Employee'}
                            className="p-1.5 text-slate-600 dark:text-slate-300 hover:text-rose-700 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/60 rounded"
                          >
                            {emp.is_active ? <Archive className="w-3.5 h-3.5" /> : <RotateCcw className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Edit Modal */}
      {editing && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 dark:bg-black/70 flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveEdit}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl max-w-xl w-full p-6 space-y-4 shadow-lg dark:shadow-2xl dark:shadow-black/50"
          >
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">Edit Employee Record</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Employee Number</label>
                <input
                  type="text"
                  required
                  value={editing.employee_number}
                  onChange={(e) => setEditing({ ...editing, employee_number: e.target.value.toUpperCase() })}
                  className="w-full px-3 py-2 font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                />
              </div>
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={editing.full_name}
                  onChange={(e) => setEditing({ ...editing, full_name: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                />
              </div>
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Position</label>
                <input
                  type="text"
                  required
                  value={editing.position}
                  onChange={(e) => setEditing({ ...editing, position: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                />
              </div>
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Department</label>
                <input
                  type="text"
                  required
                  value={editing.department}
                  onChange={(e) => setEditing({ ...editing, department: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                />
              </div>
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Schedule</label>
                <select
                  value={editing.schedule_id ?? ''}
                  onChange={(e) => setEditing({ ...editing, schedule_id: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                >
                  {schedules.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Contact Number</label>
                <input
                  type="text"
                  value={editing.contact_number}
                  onChange={(e) => setEditing({ ...editing, contact_number: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">Rest Day(s)</label>
              <div className="flex flex-wrap gap-1.5">
                {DAY_NAMES.map((name, idx) => {
                  const active = editing.rest_days.includes(idx);
                  return (
                    <button
                      key={name}
                      type="button"
                      onClick={() =>
                        setEditing({
                          ...editing,
                          rest_days: active
                            ? editing.rest_days.filter((x) => x !== idx)
                            : [...editing.rest_days, idx],
                        })
                      }
                      className={`px-2.5 py-1 text-xs font-medium rounded border ${
                        active
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-white dark:bg-slate-950 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      {name}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditing(null)}
                className="px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={saving}
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg"
              >
                {saving ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </form>
        </div>
      )}

      <ConfirmDialog
        open={Boolean(confirmToggle)}
        title={confirmToggle?.is_active ? 'Deactivate Employee?' : 'Restore Employee?'}
        description={
          confirmToggle?.is_active
            ? `${confirmToggle.full_name} (${confirmToggle.employee_number}) will be blocked from attendance check-ins while preserving all historical DTR and payroll records.`
            : `Restore ${confirmToggle?.full_name} to active status.`
        }
        confirmLabel={confirmToggle?.is_active ? 'Deactivate' : 'Restore'}
        tone={confirmToggle?.is_active ? 'danger' : 'primary'}
        onConfirm={() => confirmToggle && handleToggleActive(confirmToggle)}
        onCancel={() => setConfirmToggle(null)}
      />
    </div>
  );
}
