import React, { useMemo, useState } from 'react';
import { Download, Printer } from 'lucide-react';
import { StatusLabel } from '../../components/ui/Common';
import {
  addDaysToDateString,
  enumerateDateRange,
  formatManilaDate,
  formatManilaTime,
  formatPeso,
  toManilaDateString,
} from '../../lib/date/manila';
import { exportTableToPdf, exportToCsv, exportToExcel } from '../../lib/export/exporters';
import type {
  AttendanceRecord,
  Employee,
  Holiday,
  LeaveRequest,
  UserProfile,
} from '../../types/database';

export function ReportsPage({
  actor,
  employees,
  attendance,
  leaveRequests,
  holidays,
  initialMode = 'DAILY',
}: {
  actor: UserProfile;
  employees: Employee[];
  attendance: AttendanceRecord[];
  leaveRequests: LeaveRequest[];
  holidays: Holiday[];
  initialMode?: 'DAILY' | 'WEEKLY' | 'MONTHLY';
}) {
  const [mode, setMode] = useState<'DAILY' | 'WEEKLY' | 'MONTHLY'>(initialMode);
  const today = toManilaDateString();
  const [dailyDate, setDailyDate] = useState(today);
  const [weekStart, setWeekStart] = useState(() => addDaysToDateString(today, -6));
  const [monthStr, setMonthStr] = useState(() => today.slice(0, 7));

  const canSeeEarnings =
    actor.role === 'SUPER_ADMIN' || actor.permissions.can_edit_salary || actor.permissions.can_manage_payroll;

  const activeEmployees = useMemo(() => employees.filter((e) => e.is_active), [employees]);

  const dailyRows = useMemo(() => {
    const map = new Map(attendance.filter((a) => a.work_date === dailyDate).map((a) => [a.employee_id, a]));
    return activeEmployees.map((emp) => {
      const att = map.get(emp.id);
      const onLeave = leaveRequests.some(
        (l) => l.employee_id === emp.id && l.status === 'APPROVED' && dailyDate >= l.start_date && dailyDate <= l.end_date
      );
      const status = att ? att.status : onLeave ? 'LEAVE' : 'ABSENT';
      const dailySalary = emp.daily_rate > 0 ? emp.daily_rate : emp.monthly_rate / 22;
      const estPay = att?.actual_time_in
        ? emp.salary_type === 'HOURLY'
          ? (att.regular_hours || 8) * emp.hourly_rate
          : dailySalary
        : 0;
      return { emp, att, status, dailySalary, estPay };
    });
  }, [activeEmployees, attendance, leaveRequests, dailyDate]);

  const rangeDates = useMemo(() => {
    if (mode === 'WEEKLY') {
      return enumerateDateRange(weekStart, addDaysToDateString(weekStart, 6));
    }
    const [y, m] = monthStr.split('-').map(Number);
    const lastDay = new Date(y, m, 0).getDate();
    return enumerateDateRange(`${monthStr}-01`, `${monthStr}-${String(lastDay).padStart(2, '0')}`);
  }, [mode, weekStart, monthStr]);

  const summaryRows = useMemo(() => {
    const start = rangeDates[0];
    const end = rangeDates[rangeDates.length - 1];
    const holSet = new Set(holidays.filter((h) => h.is_verified).map((h) => h.holiday_date));

    return activeEmployees.map((emp) => {
      const empAtt = attendance.filter(
        (a) => a.employee_id === emp.id && a.work_date >= start && a.work_date <= end
      );
      const presentDays = empAtt.filter((a) => a.actual_time_in).length;
      let leaveDays = 0;
      let workingDays = 0;
      let restDayWork = 0;
      let holidayWork = 0;

      for (const d of rangeDates) {
        const dow = new Date(`${d}T12:00:00+08:00`).getDay();
        const isRest = emp.rest_days.includes(dow);
        if (!isRest) workingDays += 1;
        if (
          leaveRequests.some(
            (l) => l.employee_id === emp.id && l.status === 'APPROVED' && d >= l.start_date && d <= l.end_date
          )
        ) {
          leaveDays += 1;
        }
        const rec = empAtt.find((a) => a.work_date === d);
        if (rec?.actual_time_in) {
          if (isRest) restDayWork += 1;
          if (holSet.has(d)) holidayWork += 1;
        }
      }

      const absentDays = Math.max(0, workingDays - presentDays - leaveDays);
      const lateCount = empAtt.filter((a) => a.late_minutes > 0).length;
      const lateMins = empAtt.reduce((s, a) => s + a.late_minutes, 0);
      const undertimeMins = empAtt.reduce((s, a) => s + a.undertime_minutes, 0);
      const regularHours = empAtt.reduce((s, a) => s + a.regular_hours, 0);
      const approvedOt = empAtt.reduce((s, a) => s + a.approved_overtime_hours, 0);

      const estDaily = emp.daily_rate > 0 ? emp.daily_rate : emp.monthly_rate / 22;
      const estEarnings =
        emp.salary_type === 'HOURLY'
          ? regularHours * emp.hourly_rate + approvedOt * emp.overtime_rate * 1.25
          : presentDays * estDaily + approvedOt * (emp.overtime_rate || estDaily / 8) * 1.25;

      return {
        emp,
        workingDays,
        presentDays,
        absentDays,
        leaveDays,
        lateCount,
        lateMins,
        undertimeMins,
        regularHours,
        approvedOt,
        restDayWork,
        holidayWork,
        estEarnings,
      };
    });
  }, [activeEmployees, attendance, leaveRequests, holidays, rangeDates]);

  function handleExport(kind: 'xlsx' | 'csv' | 'pdf') {
    if (mode === 'DAILY') {
      const rows = dailyRows.map((r) => {
        const base: Record<string, string | number> = {
          Date: dailyDate,
          'Employee Number': r.emp.employee_number,
          Name: r.emp.full_name,
          Position: r.emp.position,
          Department: r.emp.department,
          'Time In': formatManilaTime(r.att?.actual_time_in),
          'Time Out': formatManilaTime(r.att?.actual_time_out),
          'Late (min)': r.att?.late_minutes ?? 0,
          'Undertime (min)': r.att?.undertime_minutes ?? 0,
          'Regular Hrs': r.att?.regular_hours ?? 0,
          'Overtime Hrs': r.att?.approved_overtime_hours ?? 0,
          Status: r.status,
        };
        if (canSeeEarnings) base['Est. Earnings (PHP)'] = Number(r.estPay.toFixed(2));
        return base;
      });
      if (kind === 'xlsx') exportToExcel(`Daily_DTR_${dailyDate}.xlsx`, 'Daily DTR', rows);
      else if (kind === 'csv') exportToCsv(`Daily_DTR_${dailyDate}.csv`, rows);
      else
        exportTableToPdf(
          `Daily_DTR_${dailyDate}.pdf`,
          'Daily DTR Report',
          `Work Date: ${formatManilaDate(dailyDate)}`,
          Object.keys(rows[0] ?? {}),
          rows.map((r) => Object.values(r))
        );
      return;
    }

    const label = mode === 'WEEKLY' ? `Weekly_DTR_${weekStart}` : `Monthly_DTR_${monthStr}`;
    const rows = summaryRows.map((r) => {
      const base: Record<string, string | number> = {
        'Employee Number': r.emp.employee_number,
        Name: r.emp.full_name,
        Department: r.emp.department,
        'Working Days': r.workingDays,
        'Present Days': r.presentDays,
        'Absent Days': r.absentDays,
        'Leave Days': r.leaveDays,
        'Late Count': r.lateCount,
        'Late (min)': r.lateMins,
        'Undertime (min)': r.undertimeMins,
        'Regular Hrs': Number(r.regularHours.toFixed(2)),
        'Approved OT': Number(r.approvedOt.toFixed(2)),
        'Rest Day Work': r.restDayWork,
        'Holiday Work': r.holidayWork,
      };
      if (canSeeEarnings) base['Est. Earnings (PHP)'] = Number(r.estEarnings.toFixed(2));
      return base;
    });
    if (kind === 'xlsx') exportToExcel(`${label}.xlsx`, `${mode} DTR`, rows);
    else if (kind === 'csv') exportToCsv(`${label}.csv`, rows);
    else
      exportTableToPdf(
        `${label}.pdf`,
        `${mode === 'WEEKLY' ? 'Weekly' : 'Monthly'} DTR Summary Report`,
        `Period: ${rangeDates[0]} to ${rangeDates[rangeDates.length - 1]}`,
        Object.keys(rows[0] ?? {}),
        rows.map((r) => Object.values(r))
      );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 no-print">
        <div>
          <h1 className="text-xl font-bold text-slate-900">DTR Reports (Daily, Weekly &amp; Monthly)</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Generated directly from Supabase attendance, leave, holiday, and overtime records.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            {(['DAILY', 'WEEKLY', 'MONTHLY'] as const).map((tab) => (
              <button
                key={tab}
                type="button"
                onClick={() => setMode(tab)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md ${
                  mode === tab ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                {tab.charAt(0) + tab.slice(1).toLowerCase()}
              </button>
            ))}
          </div>

          {mode === 'DAILY' && (
            <input
              type="date"
              value={dailyDate}
              onChange={(e) => setDailyDate(e.target.value)}
              className="px-3 py-1.5 text-xs font-mono border border-slate-200 rounded-lg bg-white"
            />
          )}
          {mode === 'WEEKLY' && (
            <input
              type="date"
              value={weekStart}
              onChange={(e) => setWeekStart(e.target.value)}
              className="px-3 py-1.5 text-xs font-mono border border-slate-200 rounded-lg bg-white"
            />
          )}
          {mode === 'MONTHLY' && (
            <input
              type="month"
              value={monthStr}
              onChange={(e) => setMonthStr(e.target.value)}
              className="px-3 py-1.5 text-xs font-mono border border-slate-200 rounded-lg bg-white"
            />
          )}
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-lg p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-semibold text-slate-900">
              {mode === 'DAILY'
                ? `Daily DTR — ${formatManilaDate(dailyDate)}`
                : mode === 'WEEKLY'
                ? `Weekly DTR — ${formatManilaDate(rangeDates[0])} to ${formatManilaDate(rangeDates[rangeDates.length - 1])}`
                : `Monthly DTR — ${monthStr}`}
            </h2>
          </div>

          <div className="flex items-center gap-1.5 no-print">
            <button
              type="button"
              onClick={() => handleExport('xlsx')}
              className="px-2.5 py-1.5 text-xs font-medium border border-slate-200 rounded-lg hover:bg-slate-50 inline-flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5" />
              Excel
            </button>
            <button
              type="button"
              onClick={() => handleExport('csv')}
              className="px-2.5 py-1.5 text-xs font-medium border border-slate-200 rounded-lg hover:bg-slate-50"
            >
              CSV
            </button>
            <button
              type="button"
              onClick={() => handleExport('pdf')}
              className="px-2.5 py-1.5 text-xs font-medium border border-slate-200 rounded-lg hover:bg-slate-50"
            >
              PDF
            </button>
            <button
              type="button"
              onClick={() => window.print()}
              className="px-2.5 py-1.5 text-xs font-medium border border-slate-200 rounded-lg hover:bg-slate-50 inline-flex items-center gap-1"
            >
              <Printer className="w-3.5 h-3.5" />
              Print
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          {mode === 'DAILY' ? (
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-medium">
                  <th className="py-2.5 pr-3">Employee #</th>
                  <th className="py-2.5 px-3">Name</th>
                  <th className="py-2.5 px-3">Department</th>
                  <th className="py-2.5 px-3">Time In</th>
                  <th className="py-2.5 px-3">Time Out</th>
                  <th className="py-2.5 px-3 text-right">Late</th>
                  <th className="py-2.5 px-3 text-right">Undertime</th>
                  <th className="py-2.5 px-3 text-right">Reg Hrs</th>
                  <th className="py-2.5 px-3 text-right">OT Hrs</th>
                  <th className="py-2.5 px-3">Status</th>
                  {canSeeEarnings && <th className="py-2.5 pl-3 text-right">Est. Earnings</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {dailyRows.map((r) => (
                  <tr key={r.emp.id} className="hover:bg-slate-50">
                    <td className="py-2.5 pr-3 font-mono font-medium text-slate-900">{r.emp.employee_number}</td>
                    <td className="py-2.5 px-3 font-medium text-slate-900">{r.emp.full_name}</td>
                    <td className="py-2.5 px-3 text-slate-600">{r.emp.department}</td>
                    <td className="py-2.5 px-3 font-mono tabular-nums">{formatManilaTime(r.att?.actual_time_in)}</td>
                    <td className="py-2.5 px-3 font-mono tabular-nums">{formatManilaTime(r.att?.actual_time_out)}</td>
                    <td className="py-2.5 px-3 font-mono tabular-nums text-right">{r.att?.late_minutes ?? 0}m</td>
                    <td className="py-2.5 px-3 font-mono tabular-nums text-right">{r.att?.undertime_minutes ?? 0}m</td>
                    <td className="py-2.5 px-3 font-mono tabular-nums text-right">{(r.att?.regular_hours ?? 0).toFixed(2)}</td>
                    <td className="py-2.5 px-3 font-mono tabular-nums text-right">
                      {(r.att?.approved_overtime_hours ?? 0).toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3">
                      <StatusLabel label={r.status} />
                    </td>
                    {canSeeEarnings && (
                      <td className="py-2.5 pl-3 font-mono tabular-nums text-right font-medium">
                        {formatPeso(r.estPay)}
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-medium">
                  <th className="py-2.5 pr-3">Employee</th>
                  <th className="py-2.5 px-2 text-right">Work Days</th>
                  <th className="py-2.5 px-2 text-right">Present</th>
                  <th className="py-2.5 px-2 text-right">Absent</th>
                  <th className="py-2.5 px-2 text-right">Leave</th>
                  <th className="py-2.5 px-2 text-right">Late (occ/min)</th>
                  <th className="py-2.5 px-2 text-right">UT (min)</th>
                  <th className="py-2.5 px-2 text-right">Reg Hrs</th>
                  <th className="py-2.5 px-2 text-right">Appr. OT</th>
                  {mode === 'MONTHLY' && <th className="py-2.5 px-2 text-right">RD / Hol</th>}
                  {canSeeEarnings && <th className="py-2.5 pl-3 text-right">Est. Earnings</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {summaryRows.map((r) => (
                  <tr key={r.emp.id} className="hover:bg-slate-50">
                    <td className="py-2.5 pr-3">
                      <p className="font-semibold text-slate-900">{r.emp.full_name}</p>
                      <p className="text-slate-500 font-mono">
                        {r.emp.employee_number} · {r.emp.department}
                      </p>
                    </td>
                    <td className="py-2.5 px-2 font-mono tabular-nums text-right">{r.workingDays}</td>
                    <td className="py-2.5 px-2 font-mono tabular-nums text-right text-emerald-700 font-medium">
                      {r.presentDays}
                    </td>
                    <td className="py-2.5 px-2 font-mono tabular-nums text-right">{r.absentDays}</td>
                    <td className="py-2.5 px-2 font-mono tabular-nums text-right">{r.leaveDays}</td>
                    <td className="py-2.5 px-2 font-mono tabular-nums text-right">
                      {r.lateCount} / {r.lateMins}m
                    </td>
                    <td className="py-2.5 px-2 font-mono tabular-nums text-right">{r.undertimeMins}m</td>
                    <td className="py-2.5 px-2 font-mono tabular-nums text-right">{r.regularHours.toFixed(2)}</td>
                    <td className="py-2.5 px-2 font-mono tabular-nums text-right">{r.approvedOt.toFixed(2)}</td>
                    {mode === 'MONTHLY' && (
                      <td className="py-2.5 px-2 font-mono tabular-nums text-right">
                        {r.restDayWork} / {r.holidayWork}
                      </td>
                    )}
                    {canSeeEarnings && (
                      <td className="py-2.5 pl-3 font-mono tabular-nums text-right font-semibold text-slate-900">
                        {formatPeso(r.estEarnings)}
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
