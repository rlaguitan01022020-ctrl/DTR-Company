import React, { useState } from 'react';
import { Clock, Save } from 'lucide-react';
import { Avatar, EmptyState, StatusLabel } from '../../components/ui/Common';
import { formatManilaDate, formatManilaTime } from '../../lib/date/manila';
import { OvertimeRequestModal } from '../overtime/OvertimePages';
import { dataService } from '../../services/dataService';
import type { AttendanceRecord, Employee, OvertimeRequest, UserProfile } from '../../types/database';

export function MyAttendancePage({
  employee,
  attendance,
}: {
  employee: Employee | null;
  attendance: AttendanceRecord[];
}) {
  const myRecords = attendance.filter((a) => a.employee_id === employee?.id);
  const presentDays = myRecords.filter((a) => a.actual_time_in).length;
  const totalLate = myRecords.reduce((s, a) => s + a.late_minutes, 0);
  const totalHours = myRecords.reduce((s, a) => s + a.regular_hours, 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-900">My Attendance</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          {employee ? `${employee.full_name} · ${employee.employee_number}` : 'Personal attendance overview'}
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <span className="text-xs text-slate-500">Recorded Present Days</span>
          <p className="text-2xl font-mono font-bold tabular-nums text-slate-900 mt-1">{presentDays}</p>
        </div>
        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <span className="text-xs text-slate-500">Cumulative Late Minutes</span>
          <p className="text-2xl font-mono font-bold tabular-nums text-rose-700 mt-1">{totalLate}m</p>
        </div>
        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <span className="text-xs text-slate-500">Regular Hours Logged</span>
          <p className="text-2xl font-mono font-bold tabular-nums text-blue-700 mt-1">{totalHours.toFixed(2)}h</p>
        </div>
      </div>

      {myRecords.length === 0 ? (
        <EmptyState
          title="No attendance logs yet"
          description="Your Time In and Time Out punches using your Employee Number will appear here."
        />
      ) : (
        <div className="bg-white border border-slate-200 rounded-lg p-4 overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 font-medium">
                <th className="py-2.5 pr-3">Work Date</th>
                <th className="py-2.5 px-3">Time In</th>
                <th className="py-2.5 px-3">Time Out</th>
                <th className="py-2.5 px-3 text-right">Late</th>
                <th className="py-2.5 px-3 text-right">Reg Hours</th>
                <th className="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {myRecords.map((r) => (
                <tr key={r.id}>
                  <td className="py-2.5 pr-3 font-mono">{formatManilaDate(r.work_date)}</td>
                  <td className="py-2.5 px-3 font-mono tabular-nums">{formatManilaTime(r.actual_time_in)}</td>
                  <td className="py-2.5 px-3 font-mono tabular-nums">{formatManilaTime(r.actual_time_out)}</td>
                  <td className="py-2.5 px-3 font-mono tabular-nums text-right">{r.late_minutes}m</td>
                  <td className="py-2.5 px-3 font-mono tabular-nums text-right">{r.regular_hours.toFixed(2)}</td>
                  <td className="py-2.5 px-3">
                    <StatusLabel label={r.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export function MyTimeRecordsPage({
  actor,
  employee,
  attendance,
  overtimeRequests,
  onReload,
  onNotify,
}: {
  actor: UserProfile;
  employee: Employee | null;
  attendance: AttendanceRecord[];
  overtimeRequests: OvertimeRequest[];
  onReload: () => void;
  onNotify: (type: 'success' | 'error', title: string, desc?: string) => void;
}) {
  const [otModalAtt, setOtModalAtt] = useState<AttendanceRecord | null>(null);
  const myRecords = attendance.filter((a) => a.employee_id === employee?.id);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-900">My Time Records</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Detailed schedule vs actual punches with direct YES / NO Overtime Request action.
        </p>
      </div>

      {myRecords.length === 0 ? (
        <EmptyState title="No time records found" description="Completed time records appear here." />
      ) : (
        <div className="bg-white border border-slate-200 rounded-lg p-4 overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 font-medium">
                <th className="py-2.5 pr-3">Date</th>
                <th className="py-2.5 px-3">Scheduled</th>
                <th className="py-2.5 px-3">Actual In / Out</th>
                <th className="py-2.5 px-3 text-right">Reg / OT</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 pl-3 text-right">Overtime Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {myRecords.map((r) => {
                const existingOt = overtimeRequests.find(
                  (o) => o.employee_id === employee?.id && o.work_date === r.work_date
                );
                return (
                  <tr key={r.id}>
                    <td className="py-2.5 pr-3 font-mono">{formatManilaDate(r.work_date)}</td>
                    <td className="py-2.5 px-3 font-mono tabular-nums text-slate-500">
                      {formatManilaTime(r.scheduled_time_in)} – {formatManilaTime(r.scheduled_time_out)}
                    </td>
                    <td className="py-2.5 px-3 font-mono tabular-nums">
                      {formatManilaTime(r.actual_time_in)} – {formatManilaTime(r.actual_time_out)}
                    </td>
                    <td className="py-2.5 px-3 font-mono tabular-nums text-right">
                      {r.regular_hours}h / {r.approved_overtime_hours}h
                    </td>
                    <td className="py-2.5 px-3">
                      <StatusLabel label={r.status} />
                    </td>
                    <td className="py-2.5 pl-3 text-right">
                      {existingOt ? (
                        <StatusLabel label={existingOt.status} />
                      ) : r.actual_time_out ? (
                        <button
                          type="button"
                          onClick={() => setOtModalAtt(r)}
                          className="px-2.5 py-1 text-xs font-semibold text-blue-700 bg-blue-50 border border-blue-200 rounded hover:bg-blue-100 inline-flex items-center gap-1"
                        >
                          <Clock className="w-3 h-3" />
                          OVERTIME REQUEST
                        </button>
                      ) : (
                        <span className="text-slate-400">Awaiting Time Out</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {otModalAtt && employee && (
        <OvertimeRequestModal
          actor={actor}
          employee={employee}
          attendance={otModalAtt}
          onClose={() => setOtModalAtt(null)}
          onSubmitted={onReload}
          onNotify={onNotify}
        />
      )}
    </div>
  );
}

export function MyProfilePage({
  actor,
  employee,
  onProfileUpdated,
  onNotify,
}: {
  actor: UserProfile;
  employee: Employee | null;
  onProfileUpdated: (p: UserProfile) => void;
  onNotify: (type: 'success' | 'error', title: string, desc?: string) => void;
}) {
  const [fullName, setFullName] = useState(actor.full_name);
  const [phone, setPhone] = useState(actor.phone ?? employee?.contact_number ?? '');
  const [address, setAddress] = useState(actor.address ?? employee?.address ?? '');
  const [saving, setSaving] = useState(false);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      const updated = await dataService.updateOwnProfile(actor.id, {
        full_name: fullName.trim(),
        phone: phone.trim() || null,
        address: address.trim() || null,
      });
      onProfileUpdated(updated);
      onNotify('success', 'Profile Updated', 'Your profile changes are saved in the Supabase profiles table.');
    } catch (err) {
      onNotify('error', 'Failed to update profile', (err as Error).message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-900">My Profile</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          All user profile data is stored in the database (<code className="font-mono">public.profiles</code>). Role and Employee Number are administrator-managed.
        </p>
      </div>

      <form onSubmit={handleSave} className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <div className="flex items-center gap-4 pb-5 border-b border-slate-100">
          <Avatar name={actor.full_name} src={employee?.photo_url ?? actor.avatar_url} size="lg" />
          <div>
            <h2 className="text-base font-bold text-slate-900">{actor.full_name}</h2>
            <p className="text-xs text-slate-500">
              {actor.email} · <span className="font-mono">{actor.role}</span>
              {actor.employee_number ? ` · ${actor.employee_number}` : ''}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="block font-medium text-slate-700 mb-1">Full Name</label>
            <input
              type="text"
              required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg"
            />
          </div>
          <div>
            <label className="block font-medium text-slate-700 mb-1">Phone Number</label>
            <input
              type="text"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="block font-medium text-slate-700 mb-1">Address</label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg inline-flex items-center gap-1.5"
        >
          <Save className="w-3.5 h-3.5" />
          {saving ? 'Saving...' : 'Save Profile'}
        </button>
      </form>
    </div>
  );
}
