import React, { useEffect, useRef, useState } from 'react';
import {
  Maximize2,
  Minimize2,
  LogOut,
  Wifi,
  WifiOff,
  Database,
  CheckCircle2,
  XCircle,
  Delete,
  CornerDownLeft,
  Info,
} from 'lucide-react';
import { Avatar, StatusLabel } from '../../components/ui/Common';
import { formatManilaDate, formatManilaTime, toManilaDateString, toManilaTime24 } from '../../lib/date/manila';
import { dataService } from '../../services/dataService';
import type { AttendancePunchResult, CompanySettings } from '../../types/database';

interface KioskLookupInfo {
  found: boolean;
  employee_number?: string;
  full_name?: string;
  position?: string;
  department?: string;
  photo_url?: string | null;
  is_active?: boolean;
  next_event?: 'TIME_IN' | 'TIME_OUT';
}

export function AttendanceKioskPage({
  company,
  onExitKiosk,
  onPunchRecorded,
}: {
  company: CompanySettings;
  onExitKiosk: () => void;
  onPunchRecorded: () => void;
}) {
  const [clock, setClock] = useState(() => new Date());
  const [employeeNumber, setEmployeeNumber] = useState('');
  const [pin, setPin] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [lookup, setLookup] = useState<KioskLookupInfo | null>(null);
  const [result, setResult] = useState<AttendancePunchResult | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(Boolean(document.fullscreenElement));
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showGuide, setShowGuide] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const t = setInterval(() => setClock(new Date()), 1000);
    const onFsChange = () => setIsFullscreen(Boolean(document.fullscreenElement));
    const onOnline = () => setIsOnline(true);
    const onOffline = () => setIsOnline(false);

    document.addEventListener('fullscreenchange', onFsChange);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);

    return () => {
      clearInterval(t);
      document.removeEventListener('fullscreenchange', onFsChange);
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, []);

  // Immediately show employee name & next punch state when Employee Number is typed
  useEffect(() => {
    const trimmed = employeeNumber.trim();
    if (!trimmed) {
      setLookup(null);
      return;
    }
    let cancelled = false;
    dataService.lookupEmployeeByNumber(trimmed).then((res) => {
      if (!cancelled) setLookup(res);
    });
    return () => {
      cancelled = true;
    };
  }, [employeeNumber, result]);

  async function enterFullscreen() {
    try {
      await (containerRef.current ?? document.documentElement).requestFullscreen();
    } catch {
      // browser blocked fullscreen
    }
  }

  async function exitFullscreen() {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
    } catch {
      // ignore
    }
  }

  async function handlePunch(e?: React.FormEvent) {
    e?.preventDefault();
    const cleaned = employeeNumber.trim();
    if (!cleaned || submitting) return;
    setSubmitting(true);
    try {
      const res = await dataService.punchAttendanceByEmployeeNumber(cleaned, {
        pin: pin.trim() || undefined,
        source: 'KIOSK',
      });
      setResult(res);
      if (res.success) {
        onPunchRecorded();
        setPin('');
        const refreshed = await dataService.lookupEmployeeByNumber(cleaned);
        setLookup(refreshed);
      }
    } finally {
      setSubmitting(false);
      inputRef.current?.focus();
    }
  }

  return (
    <div
      ref={containerRef}
      className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between p-4 sm:p-8"
    >
      {/* Kiosk Top Bar — zero admin/salary/payroll access */}
      <header className="max-w-5xl w-full mx-auto flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          {company.company_logo_url ? (
            <img
              src={company.company_logo_url}
              alt={company.company_name}
              referrerPolicy="no-referrer"
              className="w-10 h-10 rounded-lg object-cover border border-slate-700"
            />
          ) : (
            <div className="w-10 h-10 rounded-lg bg-blue-600 text-white font-bold flex items-center justify-center">
              PL
            </div>
          )}
          <div>
            <h1 className="text-base font-bold text-white leading-tight">{company.company_name}</h1>
            <p className="text-xs text-slate-400">Entrance Attendance Kiosk · Employee Number Check-In</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-3 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs">
            <span className="inline-flex items-center gap-1.5 text-slate-300">
              {isOnline ? <Wifi className="w-3.5 h-3.5 text-emerald-400" /> : <WifiOff className="w-3.5 h-3.5 text-rose-400" />}
              {isOnline ? 'Network Connected' : 'Offline'}
            </span>
            <span className="text-slate-700">|</span>
            <span className="inline-flex items-center gap-1.5 text-slate-300">
              <Database className="w-3.5 h-3.5 text-blue-400" />
              {dataService.isLiveSupabase() ? 'Supabase Connected' : 'Local Preview DB'}
            </span>
          </div>

          <button
            type="button"
            onClick={() => setShowGuide((v) => !v)}
            className="px-3 py-2 text-xs font-medium text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-lg inline-flex items-center gap-1.5"
          >
            <Info className="w-3.5 h-3.5" />
            Setup Guide
          </button>

          {!isFullscreen ? (
            <button
              type="button"
              onClick={enterFullscreen}
              className="px-3 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg inline-flex items-center gap-1.5"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              MAXIMIZE
            </button>
          ) : (
            <button
              type="button"
              onClick={exitFullscreen}
              className="px-3 py-2 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg inline-flex items-center gap-1.5"
            >
              <Minimize2 className="w-3.5 h-3.5" />
              MINIMIZE
            </button>
          )}

          <button
            type="button"
            onClick={async () => {
              await exitFullscreen();
              onExitKiosk();
            }}
            className="px-3 py-2 text-xs font-semibold text-slate-200 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-lg inline-flex items-center gap-1.5"
          >
            <LogOut className="w-3.5 h-3.5" />
            EXIT KIOSK
          </button>
        </div>
      </header>

      {showGuide && (
        <div className="max-w-5xl w-full mx-auto mt-4 p-4 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-300 space-y-1.5">
          <p className="font-semibold text-white">Windows &amp; Android Kiosk Sleep-Prevention Setup</p>
          <p>
            Browser tabs remain active while the device stays awake; a standard web page cannot override an OS lock screen.
          </p>
          <p>
            • <strong>Windows:</strong> Set Power &amp; Sleep to Never, then launch Chrome/Edge with{' '}
            <code className="font-mono text-blue-300">--kiosk --edge-kiosk-type=fullscreen</code>.
          </p>
          <p>
            • <strong>Android Tablet:</strong> Enable &ldquo;Stay awake while charging&rdquo; in Developer Options and pin this screen via Android Screen Pinning.
          </p>
        </div>
      )}

      {/* Main Kiosk Center Stage */}
      <main className="max-w-4xl w-full mx-auto my-auto py-8 grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
        <div className="md:col-span-5 text-center md:text-left space-y-3">
          <p className="text-xs font-semibold uppercase tracking-widest text-blue-400">
            Philippine Standard Time · Asia/Manila (24-Hr)
          </p>
          <div className="text-5xl sm:text-6xl font-mono font-bold tabular-nums text-white tracking-tight">
            {toManilaTime24(clock)}
          </div>
          <p className="text-lg text-slate-300 font-medium">{formatManilaDate(toManilaDateString(clock))}</p>
          <div className="pt-4 border-t border-slate-800 text-xs text-slate-400 space-y-1.5">
            <p>1. Enter your Employee Number.</p>
            <p>2. Verify your displayed name, then press Submit.</p>
            <p>3. 1st = Time In, 2nd = Time Out, 3rd = Time In (zero delay).</p>
          </div>
        </div>

        <div className="md:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-4">
          {result && (
            <div
              className={`rounded-xl border p-4 ${
                result.success ? 'bg-emerald-950/60 border-emerald-700' : 'bg-rose-950/60 border-rose-700'
              }`}
            >
              {result.success ? (
                <div className="flex items-center gap-4">
                  <Avatar name={result.full_name ?? 'Employee'} src={result.photo_url} size="lg" />
                  <div className="flex-1 min-w-0">
                    <div className="inline-flex items-center gap-1.5 text-emerald-400 text-xs font-bold">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{result.event_type === 'TIME_IN' ? 'TIME IN RECORDED' : 'TIME OUT RECORDED'}</span>
                    </div>
                    <h2 className="text-lg font-bold text-white truncate">{result.full_name}</h2>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-300">
                      <span className="font-mono font-semibold text-white">{result.employee_number}</span>
                      <span>·</span>
                      <span className="font-mono tabular-nums">{formatManilaTime(result.recorded_at)}</span>
                      {result.status && <StatusLabel label={result.status} />}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex items-start gap-3">
                  <XCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                  <div>
                    <h3 className="text-sm font-bold text-white">Attendance Not Recorded</h3>
                    <p className="text-xs text-rose-200 mt-0.5">{result.message}</p>
                  </div>
                </div>
              )}
            </div>
          )}

          <form onSubmit={handlePunch} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-2">
                Employee Number
              </label>
              <input
                ref={inputRef}
                type="text"
                autoFocus
                value={employeeNumber}
                onChange={(e) => setEmployeeNumber(e.target.value.toUpperCase())}
                placeholder="Enter Employee Number"
                className="w-full px-4 py-4 text-2xl font-mono font-bold tracking-wider bg-slate-950 text-white border border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            {/* Live Employee Name Display */}
            {employeeNumber.trim() && (
              <div className="rounded-xl border border-slate-700 bg-slate-950/90 px-4 py-3">
                {lookup?.found ? (
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <Avatar name={lookup.full_name ?? 'Employee'} src={lookup.photo_url} size="md" />
                      <div className="min-w-0">
                        <p className="text-sm font-bold text-white truncate">{lookup.full_name}</p>
                        <p className="text-xs text-slate-400 truncate">
                          <span className="font-mono text-slate-300">{lookup.employee_number}</span> · {lookup.position}
                        </p>
                      </div>
                    </div>
                    <StatusLabel
                      label={lookup.is_active === false ? 'INACTIVE' : `NEXT: ${lookup.next_event === 'TIME_OUT' ? 'TIME OUT' : 'TIME IN'}`}
                      tone={lookup.is_active === false ? 'red' : lookup.next_event === 'TIME_OUT' ? 'orange' : 'blue'}
                    />
                  </div>
                ) : (
                  <p className="text-xs text-slate-400">
                    No matching employee found for <span className="font-mono text-slate-200">{employeeNumber.trim()}</span>
                  </p>
                )}
              </div>
            )}

            {company.require_kiosk_pin && (
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">PIN</label>
                <input
                  type="password"
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="Enter PIN"
                  className="w-full px-4 py-3 text-lg font-mono bg-slate-950 text-white border border-slate-700 rounded-xl"
                />
              </div>
            )}

            <div className="grid grid-cols-4 gap-2 pt-1">
              {['1', '2', '3', 'EMP-', '4', '5', '6', '2026-', '7', '8', '9', '0'].map((k) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => {
                    setEmployeeNumber((p) => p + k);
                    inputRef.current?.focus();
                  }}
                  className="py-3.5 text-base font-mono font-semibold bg-slate-800 hover:bg-slate-700 text-white rounded-xl border border-slate-700"
                >
                  {k}
                </button>
              ))}
              <button
                type="button"
                onClick={() => setEmployeeNumber((p) => p.slice(0, -1))}
                className="py-3.5 text-sm font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl border border-slate-700 inline-flex items-center justify-center"
              >
                <Delete className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => {
                  setEmployeeNumber('');
                  setLookup(null);
                  setResult(null);
                }}
                className="py-3.5 text-sm font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl border border-slate-700"
              >
                Clear
              </button>
              <button
                type="submit"
                disabled={submitting || !employeeNumber.trim()}
                className="col-span-2 py-3.5 px-4 text-base font-semibold bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-xl inline-flex items-center justify-center gap-2"
              >
                <CornerDownLeft className="w-5 h-5" />
                {submitting
                  ? 'Saving...'
                  : lookup?.found
                  ? `Clock ${lookup.next_event === 'TIME_OUT' ? 'Out' : 'In'}`
                  : 'Clock In / Out'}
              </button>
            </div>
          </form>
        </div>
      </main>

      <footer className="max-w-5xl w-full mx-auto text-xs text-slate-500 flex items-center justify-between border-t border-slate-800 pt-4">
        <span>Kiosk Session Locked to Attendance Entry Only</span>
        <span>Timezone: Asia/Manila</span>
      </footer>
    </div>
  );
}
