import React, { useMemo, useState } from 'react';
import { Download, Printer, Grid2X2, FileSpreadsheet, CheckSquare, Square } from 'lucide-react';
import { EmptyState } from '../../components/ui/Common';
import { buildPayslipTemplateData, formatSlipNum } from '../../lib/payroll/payslipFormat';
import { exportMassPayslips8UpPdf, exportPayslipPdf } from '../../lib/export/exporters';
import type { CompanySettings, PayrollPeriod, PayrollRecord, UserProfile } from '../../types/database';

function PayslipTemplateCard({
  record,
  period,
  company,
  compact = false,
}: {
  record: PayrollRecord;
  period: PayrollPeriod;
  company: CompanySettings;
  compact?: boolean;
}) {
  const d = buildPayslipTemplateData(record, period, company);

  const textSize = compact ? 'text-[6.2px] leading-[1.08]' : 'text-[13px] leading-snug';
  const cellPad = compact ? 'px-1 py-[0.7px]' : 'px-2.5 py-1';
  const headerPad = compact ? 'px-1.5 py-[2px]' : 'px-4 py-2.5';
  const noteSize = compact ? 'text-[5.5px] leading-tight px-1 py-[1px]' : 'text-[11px] px-2.5 py-1.5';

  return (
    <div
      className={`bg-white text-black border-2 border-black select-text ${
        compact ? 'payslip-slip-80 flex flex-col justify-between' : 'w-full max-w-[460px] mx-auto shadow-md'
      }`}
      style={{ fontFamily: 'Arial, Helvetica, sans-serif' }}
    >
      {/* Top Company Header */}
      <div className={`flex items-center justify-center gap-2 border-b border-black bg-white ${headerPad}`}>
        {d.companyLogoUrl ? (
          <img
            src={d.companyLogoUrl}
            alt={d.companyName}
            className={compact ? 'h-3 w-auto object-contain' : 'h-7 w-auto object-contain'}
          />
        ) : (
          <svg
            viewBox="0 0 36 22"
            className={compact ? 'h-2.5 w-4 shrink-0' : 'h-6 w-9 shrink-0'}
            aria-hidden="true"
          >
            <polygon points="2,6 18,1 34,8 18,14" fill="#1d4ed8" />
            <polygon points="2,6 18,14 18,21 2,13" fill="#0f172a" />
            <polygon points="34,8 18,14 18,21 34,15" fill="#2563eb" />
          </svg>
        )}
        <span
          className={`font-extrabold tracking-wide text-[#1d4ed8] uppercase truncate ${
            compact ? 'text-[8.5px]' : 'text-lg'
          }`}
        >
          {d.companyName}
        </span>
      </div>

      {/* Main Payslip Grid */}
      <table className={`w-full border-collapse table-fixed flex-1 ${textSize}`}>
        <colgroup>
          <col style={{ width: '38%' }} />
          <col style={{ width: '28%' }} />
          <col style={{ width: '34%' }} />
        </colgroup>
        <tbody>
          <tr className="border-b border-black">
            <td className={`border-r border-black font-normal ${cellPad}`}>Name:</td>
            <td colSpan={2} className={`font-semibold truncate ${cellPad}`}>
              {d.employeeName}
            </td>
          </tr>
          <tr className="border-b border-black">
            <td className={`border-r border-black font-normal ${cellPad}`}>Pay Period:</td>
            <td colSpan={2} className={`truncate ${cellPad}`}>
              {d.payPeriodLabel}
            </td>
          </tr>
          <tr className="border-b border-black">
            <td className={`${cellPad}`}>New rate</td>
            <td className={`border-r border-black text-right tabular-nums ${cellPad}`}>
              {formatSlipNum(d.newRate)}
            </td>
            <td className={cellPad}>&nbsp;</td>
          </tr>
          <tr className="border-b border-black">
            <td className={`border-r border-black ${cellPad}`}>Days</td>
            <td className={`border-r border-black text-right tabular-nums ${cellPad}`}>
              {formatSlipNum(d.daysWorked)}
            </td>
            <td className={`text-right tabular-nums ${cellPad}`}>{formatSlipNum(d.basicPay)}</td>
          </tr>
          <tr className="border-b border-black">
            <td className={`border-r border-black ${cellPad}`}>OT1</td>
            <td className={`border-r border-black text-right tabular-nums ${cellPad}`}>
              {formatSlipNum(d.ot1Hours)}
            </td>
            <td className={`text-right tabular-nums ${cellPad}`}>{formatSlipNum(d.ot1Pay)}</td>
          </tr>
          <tr className="border-b border-black">
            <td className={`border-r border-black ${cellPad}`}>OT2</td>
            <td className={`border-r border-black text-right tabular-nums ${cellPad}`}>
              {formatSlipNum(d.ot2Hours)}
            </td>
            <td className={`text-right tabular-nums ${cellPad}`}>{formatSlipNum(d.ot2Pay)}</td>
          </tr>
          <tr className="border-b border-black">
            <td colSpan={2} className={`border-r border-black ${cellPad}`}>
              OTL/SL
            </td>
            <td className={`text-right tabular-nums ${cellPad}`}>{formatSlipNum(d.otlSl)}</td>
          </tr>
          <tr className="border-b border-black">
            <td colSpan={2} className={`border-r border-black ${cellPad}`}>
              Usd
            </td>
            <td className={`text-right tabular-nums ${cellPad}`}>{formatSlipNum(d.usd)}</td>
          </tr>
          <tr className="border-b border-black">
            <td colSpan={2} className={`border-r border-black ${cellPad}`}>
              Legal Holiday
            </td>
            <td className={`text-right tabular-nums ${cellPad}`}>{formatSlipNum(d.legalHoliday)}</td>
          </tr>
          <tr className="border-b border-black">
            <td colSpan={2} className={`border-r border-black ${cellPad}`}>
              Special Holiday
            </td>
            <td className={`text-right tabular-nums ${cellPad}`}>{formatSlipNum(d.specialHoliday)}</td>
          </tr>
          <tr className="border-b border-black">
            <td colSpan={2} className={`border-r border-black font-bold italic ${cellPad}`}>
              Gross Earn
            </td>
            <td className={`text-right font-bold italic tabular-nums ${cellPad}`}>
              {formatSlipNum(d.grossEarn)}
            </td>
          </tr>
          <tr className="border-b border-black">
            <td colSpan={2} className={`border-r border-black font-bold italic text-[#dc2626] ${cellPad}`}>
              DEDUCTIONS:
            </td>
            <td className={cellPad}>&nbsp;</td>
          </tr>
          <tr className="border-b border-black">
            <td colSpan={2} className={`border-r border-black ${cellPad}`}>
              <div className="flex items-center justify-between gap-1">
                <span>SSS Share</span>
                {d.sssShareRemarks && (
                  <span className="truncate font-normal">({d.sssShareRemarks})</span>
                )}
              </div>
            </td>
            <td className={`text-right tabular-nums ${cellPad}`}>{formatSlipNum(d.sssShare)}</td>
          </tr>
          <tr className="border-b border-black">
            <td colSpan={2} className={`border-r border-black ${cellPad}`}>
              <div className="flex items-center justify-between gap-1">
                <span>PHIC Share</span>
                {d.phicShareRemarks && (
                  <span className="truncate font-normal">({d.phicShareRemarks})</span>
                )}
              </div>
            </td>
            <td className={`text-right tabular-nums ${cellPad}`}>{formatSlipNum(d.phicShare)}</td>
          </tr>
          <tr className="border-b border-black">
            <td colSpan={2} className={`border-r border-black ${cellPad}`}>
              PAG-IBIG Share
            </td>
            <td className={`text-right tabular-nums ${cellPad}`}>{formatSlipNum(d.pagibigShare)}</td>
          </tr>
          <tr className="border-b border-black">
            <td colSpan={2} className={`border-r border-black ${cellPad}`}>
              SSS Loan
            </td>
            <td className={`text-right tabular-nums ${cellPad}`}>{formatSlipNum(d.sssLoan)}</td>
          </tr>
          <tr className="border-b border-black">
            <td colSpan={2} className={`border-r border-black ${cellPad}`}>
              Pag-ibig Loan
            </td>
            <td className={`text-right tabular-nums ${cellPad}`}>{formatSlipNum(d.pagibigLoan)}</td>
          </tr>
          <tr className="border-b border-black">
            <td colSpan={2} className={`border-r border-black ${cellPad}`}>
              Coop Share
            </td>
            <td className={`text-right tabular-nums ${cellPad}`}>{formatSlipNum(d.coopShare)}</td>
          </tr>
          <tr className="border-b border-black">
            <td colSpan={2} className={`border-r border-black ${cellPad}`}>
              Coop Loan
            </td>
            <td className={`text-right tabular-nums ${cellPad}`}>{formatSlipNum(d.coopLoan)}</td>
          </tr>
          <tr className="border-b border-black">
            <td colSpan={2} className={`border-r border-black ${cellPad}`}>
              Donation
            </td>
            <td className={`text-right tabular-nums ${cellPad}`}>{formatSlipNum(d.donation)}</td>
          </tr>
          <tr className="border-b border-black">
            <td colSpan={2} className={`border-r border-black ${cellPad}`}>
              Cash advance
            </td>
            <td className={`text-right tabular-nums ${cellPad}`}>{formatSlipNum(d.cashAdvance)}</td>
          </tr>
          <tr className="border-b border-black">
            <td colSpan={2} className={`border-r border-black ${cellPad}`}>
              Late
            </td>
            <td className={`text-right tabular-nums ${cellPad}`}>{formatSlipNum(d.late)}</td>
          </tr>
          <tr className="border-b border-black">
            <td colSpan={2} className={`border-r border-black font-bold italic ${cellPad}`}>
              Total Deductions:
            </td>
            <td className={`text-right font-bold italic tabular-nums ${cellPad}`}>
              {formatSlipNum(d.totalDeductions)}
            </td>
          </tr>
          <tr className="border-b border-black">
            <td colSpan={2} className={`border-r border-black font-bold italic ${cellPad}`}>
              <span className="bg-[#ffff00] px-0.5 text-black">NET PAY</span>:
            </td>
            <td className={`bg-[#ffff00] text-right font-bold italic tabular-nums text-black ${cellPad}`}>
              {formatSlipNum(d.netPay)}
            </td>
          </tr>
        </tbody>
      </table>

      {/* Footer Note */}
      <div className={`text-center font-normal truncate bg-white text-black ${noteSize}`}>
        NOTE: {d.note}
      </div>
    </div>
  );
}

export function PayslipsPage({
  actor,
  company,
  payrollPeriods,
  payrollRecords,
}: {
  actor: UserProfile;
  company: CompanySettings;
  payrollPeriods: PayrollPeriod[];
  payrollRecords: PayrollRecord[];
}) {
  const isStaffManager = actor.role === 'SUPER_ADMIN' || actor.role === 'ADMIN';

  const visiblePeriods = useMemo(() => {
    if (!isStaffManager) {
      return payrollPeriods.filter((p) => p.status === 'FINALIZED' || p.status === 'PAID');
    }
    return payrollPeriods;
  }, [payrollPeriods, isStaffManager]);

  const [selectedPeriodId, setSelectedPeriodId] = useState(visiblePeriods[0]?.id ?? '');
  const activePeriod = useMemo(
    () => visiblePeriods.find((p) => p.id === selectedPeriodId) ?? visiblePeriods[0] ?? null,
    [visiblePeriods, selectedPeriodId]
  );

  const periodRecords = useMemo(() => {
    if (!activePeriod) return [];
    return payrollRecords.filter((r) => {
      if (r.payroll_period_id !== activePeriod.id) return false;
      if (!isStaffManager && actor.employee_id) {
        return r.employee_id === actor.employee_id;
      }
      return true;
    });
  }, [payrollRecords, activePeriod, isStaffManager, actor.employee_id]);

  const [viewMode, setViewMode] = useState<'single' | 'mass'>(isStaffManager ? 'single' : 'single');
  const [selectedRecordId, setSelectedRecordId] = useState(periodRecords[0]?.id ?? '');
  const [sheetLayout, setSheetLayout] = useState<'2x4' | '4x2'>('2x4');
  const [excludedIds, setExcludedIds] = useState<Record<string, boolean>>({});

  const activeRecord =
    periodRecords.find((r) => r.id === selectedRecordId) ?? periodRecords[0] ?? null;

  const massRecords = useMemo(
    () => periodRecords.filter((r) => !excludedIds[r.id]),
    [periodRecords, excludedIds]
  );

  const massSheets = useMemo(() => {
    const pages: PayrollRecord[][] = [];
    for (let i = 0; i < massRecords.length; i += 8) {
      pages.push(massRecords.slice(i, i + 8));
    }
    return pages;
  }, [massRecords]);

  function toggleAllSelection() {
    if (massRecords.length === periodRecords.length) {
      const next: Record<string, boolean> = {};
      periodRecords.forEach((r) => {
        next[r.id] = true;
      });
      setExcludedIds(next);
    } else {
      setExcludedIds({});
    }
  }

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 no-print">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">
            Employee Payslips &amp; 8-per-Sheet Mass Print
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Official payslip layout with itemized deductions and 80mm × 80mm (3 1/8&quot; width) 8-up mass sheet printing.
          </p>
        </div>

        {visiblePeriods.length > 0 && (
          <div className="flex flex-wrap items-center gap-2">
            <select
              value={activePeriod?.id ?? ''}
              onChange={(e) => {
                setSelectedPeriodId(e.target.value);
                setSelectedRecordId('');
                setExcludedIds({});
              }}
              className="px-3 py-2 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100"
            >
              {visiblePeriods.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.period_name} ({p.status})
                </option>
              ))}
            </select>

            {isStaffManager && (
              <div className="inline-flex rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-0.5">
                <button
                  type="button"
                  onClick={() => setViewMode('single')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition ${
                    viewMode === 'single'
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  Single Payslip
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode('mass')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md inline-flex items-center gap-1.5 transition ${
                    viewMode === 'mass'
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Grid2X2 className="w-3.5 h-3.5" />
                  Mass Print (8/Sheet)
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {!activePeriod || periodRecords.length === 0 ? (
        <EmptyState
          title="No payslips available for this period"
          description={
            actor.role === 'EMPLOYEE'
              ? 'Your payslips appear here once an administrator finalizes a payroll period.'
              : 'Generate a payroll period in Payroll Management to preview and mass-print payslips.'
          }
        />
      ) : viewMode === 'single' && activeRecord ? (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-sm dark:shadow-lg dark:shadow-black/30 no-print">
            <div className="flex items-center gap-2">
              <label className="text-xs font-medium text-slate-600 dark:text-slate-300">Employee:</label>
              <select
                value={activeRecord.id}
                onChange={(e) => setSelectedRecordId(e.target.value)}
                className="px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
              >
                {periodRecords.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.employee_number} — {r.employee_name}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => exportPayslipPdf(activeRecord, activePeriod, company)}
                className="px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg inline-flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                Download PDF
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="px-3.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 inline-flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" />
                Print Payslip
              </button>
              {isStaffManager && (
                <button
                  type="button"
                  onClick={() => setViewMode('mass')}
                  className="px-3.5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg inline-flex items-center gap-1.5"
                >
                  <Grid2X2 className="w-3.5 h-3.5" />
                  Print Mass 8/Sheet (80×80mm)
                </button>
              )}
            </div>
          </div>

          <div className="py-2 flex justify-center">
            <PayslipTemplateCard record={activeRecord} period={activePeriod} company={company} />
          </div>
        </div>
      ) : (
        <div className="space-y-5">
          {/* Mass Print Toolbar */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-4 space-y-3 shadow-sm dark:shadow-lg dark:shadow-black/30 no-print">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                  Mass Payslip Sheet Builder — 8 Payslips per Sheet (80mm × 80mm / 3 1/8&quot; width)
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Selected {massRecords.length} of {periodRecords.length} employee(s) · {massSheets.length} sheet(s) to print.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <select
                  value={sheetLayout}
                  onChange={(e) => setSheetLayout(e.target.value as '2x4' | '4x2')}
                  className="px-3 py-2 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                >
                  <option value="2x4">2 Columns × 4 Rows (Portrait Legal/Folio)</option>
                  <option value="4x2">4 Columns × 2 Rows (Landscape Legal)</option>
                </select>
                <button
                  type="button"
                  disabled={massRecords.length === 0}
                  onClick={() => exportMassPayslips8UpPdf(massRecords, activePeriod, company, sheetLayout)}
                  className="px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 inline-flex items-center gap-1.5 disabled:opacity-40"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                  Download 8-Up PDF
                </button>
                <button
                  type="button"
                  disabled={massRecords.length === 0}
                  onClick={() => window.print()}
                  className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg inline-flex items-center gap-1.5 disabled:opacity-40"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print Mass Payslips (8 per Sheet)
                </button>
              </div>
            </div>

            {/* Employee Selection Chips */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-1.5">
              <button
                type="button"
                onClick={toggleAllSelection}
                className="px-2.5 py-1 text-[11px] font-semibold rounded border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 inline-flex items-center gap-1"
              >
                {massRecords.length === periodRecords.length ? (
                  <CheckSquare className="w-3 h-3 text-blue-600" />
                ) : (
                  <Square className="w-3 h-3" />
                )}
                {massRecords.length === periodRecords.length ? 'Deselect All' : 'Select All'}
              </button>
              {periodRecords.map((r) => {
                const included = !excludedIds[r.id];
                return (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() =>
                      setExcludedIds((prev) => ({
                        ...prev,
                        [r.id]: included,
                      }))
                    }
                    className={`px-2.5 py-1 text-[11px] rounded border transition ${
                      included
                        ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-300 dark:border-blue-700 text-blue-800 dark:text-blue-200 font-medium'
                        : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-400 line-through'
                    }`}
                  >
                    {r.employee_number} · {r.employee_name}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 8-per-Sheet Preview & Print Container */}
          {massSheets.length === 0 ? (
            <EmptyState
              title="No employees selected for mass print"
              description="Select at least one employee above to generate the 80mm × 80mm payslip sheets."
            />
          ) : (
            <div className="space-y-6">
              {massSheets.map((sheetRecords, sheetIdx) => (
                <div
                  key={sheetIdx}
                  className="bg-slate-100 dark:bg-slate-900/70 border border-slate-200 dark:border-slate-700 rounded-xl p-4 overflow-x-auto print:bg-white print:border-0 print:p-0"
                >
                  <p className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-3 no-print">
                    Sheet {sheetIdx + 1} of {massSheets.length} · {sheetRecords.length} / 8 Payslips (80mm × 80mm each)
                  </p>
                  <div
                    className={
                      sheetLayout === '4x2'
                        ? 'mass-payslip-sheet-4x2 grid gap-2.5 justify-center'
                        : 'mass-payslip-sheet-2x4 grid gap-2.5 justify-center'
                    }
                    style={{
                      gridTemplateColumns:
                        sheetLayout === '4x2' ? 'repeat(4, 80mm)' : 'repeat(2, 80mm)',
                    }}
                  >
                    {sheetRecords.map((rec) => (
                      <PayslipTemplateCard
                        key={rec.id}
                        record={rec}
                        period={activePeriod}
                        company={company}
                        compact
                      />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
