import React, { useMemo, useState } from 'react';
import { Calculator, Lock, CheckCircle2, FileText, Download, PlusCircle, Printer } from 'lucide-react';
import { ConfirmDialog, EmptyState, StatusLabel } from '../../components/ui/Common';
import {
  addDaysToDateString,
  formatManilaDate,
  formatPeso,
  toManilaDateString,
} from '../../lib/date/manila';
import {
  exportMassPayslips8UpPdf,
  exportPayslipPdf,
  exportToCsv,
  exportToExcel,
} from '../../lib/export/exporters';
import { dataService } from '../../services/dataService';
import type {
  AttendanceRecord,
  CompanySettings,
  Employee,
  Holiday,
  LeaveRequest,
  OvertimeRequest,
  PayrollPeriod,
  PayrollRecord,
  Schedule,
  UserProfile,
} from '../../types/database';

export function PayrollPage({
  actor,
  company,
  employees,
  schedules,
  attendance,
  overtimeRequests,
  leaveRequests,
  holidays,
  payrollPeriods,
  payrollRecords,
  onReload,
  onNotify,
  onOpenPayslips,
}: {
  actor: UserProfile;
  company: CompanySettings;
  employees: Employee[];
  schedules: Schedule[];
  attendance: AttendanceRecord[];
  overtimeRequests: OvertimeRequest[];
  leaveRequests: LeaveRequest[];
  holidays: Holiday[];
  payrollPeriods: PayrollPeriod[];
  payrollRecords: PayrollRecord[];
  onReload: () => void;
  onNotify: (type: 'success' | 'error', title: string, desc?: string) => void;
  onOpenPayslips?: () => void;
}) {
  const today = toManilaDateString();
  const [periodName, setPeriodName] = useState(`Payroll ${today.slice(0, 7)} Cutoff`);
  const [startDate, setStartDate] = useState(() => addDaysToDateString(today, -14));
  const [endDate, setEndDate] = useState(today);
  const [payDate, setPayDate] = useState(() => addDaysToDateString(today, 3));
  const [selectedPeriodId, setSelectedPeriodId] = useState<string>(payrollPeriods[0]?.id ?? '');
  const [adjustingRecord, setAdjustingRecord] = useState<PayrollRecord | null>(null);
  const [adjType, setAdjType] = useState<'ADDITION' | 'DEDUCTION'>('ADDITION');
  const [adjCategory, setAdjCategory] = useState('Incentive / Bonus');
  const [adjAmount, setAdjAmount] = useState('0');
  const [adjReason, setAdjReason] = useState('');
  const [confirmFinalize, setConfirmFinalize] = useState<PayrollPeriod | null>(null);
  const [generating, setGenerating] = useState(false);

  const activePeriod = useMemo(
    () => payrollPeriods.find((p) => p.id === selectedPeriodId) ?? payrollPeriods[0] ?? null,
    [payrollPeriods, selectedPeriodId]
  );

  const periodRecords = useMemo(
    () => (activePeriod ? payrollRecords.filter((r) => r.payroll_period_id === activePeriod.id) : []),
    [payrollRecords, activePeriod]
  );

  const totals = useMemo(() => {
    return periodRecords.reduce(
      (acc, r) => ({
        gross: acc.gross + r.gross_pay,
        net: acc.net + r.net_pay,
        ot: acc.ot + r.regular_overtime_pay + r.rest_day_overtime_pay + r.holiday_overtime_pay,
        holiday: acc.holiday + r.special_holiday_pay + r.regular_holiday_pay + r.holiday_rest_day_pay,
      }),
      { gross: 0, net: 0, ot: 0, holiday: 0 }
    );
  }, [periodRecords]);

  async function handleGenerate(e: React.FormEvent) {
    e.preventDefault();
    setGenerating(true);
    try {
      const { period } = await dataService.generatePayrollPeriod(
        actor,
        {
          period_name: periodName.trim(),
          start_date: startDate,
          end_date: endDate,
          pay_date: payDate,
          payroll_schedule: company.payroll_schedule,
        },
        {
          employees,
          schedules,
          attendance,
          overtimeRequests,
          leaveRequests,
          holidays,
          companySettings: company,
        }
      );
      setSelectedPeriodId(period.id);
      onNotify('success', 'Payroll Generated', `${period.period_name} saved as DRAFT.`);
      onReload();
    } catch (err) {
      onNotify('error', 'Payroll generation failed', (err as Error).message);
    } finally {
      setGenerating(false);
    }
  }

  async function handleStatusTransition(period: PayrollPeriod, next: PayrollPeriod['status']) {
    try {
      await dataService.updatePayrollPeriodStatus(actor, period, next);
      onNotify('success', `Payroll ${next}`, `${period.period_name} moved to ${next}.`);
      setConfirmFinalize(null);
      onReload();
    } catch (err) {
      onNotify('error', 'Status change failed', (err as Error).message);
    }
  }

  async function handleSaveAdjustment(e: React.FormEvent) {
    e.preventDefault();
    if (!adjustingRecord || !adjReason.trim()) return;
    try {
      await dataService.addPayrollAdjustment(actor, adjustingRecord, {
        adjustment_type: adjType,
        category: adjCategory,
        amount: Number(adjAmount) || 0,
        reason: adjReason.trim(),
      });
      onNotify('success', 'Adjustment Saved', `Updated ${adjustingRecord.employee_name}'s payroll.`);
      setAdjustingRecord(null);
      setAdjReason('');
      onReload();
    } catch (err) {
      onNotify('error', 'Adjustment failed', (err as Error).message);
    }
  }

  function exportPayroll(kind: 'xlsx' | 'csv') {
    if (!activePeriod) return;
    const rows = periodRecords.map((r) => ({
      'Employee Number': r.employee_number,
      'Employee Name': r.employee_name,
      Department: r.department,
      'Salary Type': r.salary_type,
      'Days Worked': r.days_worked,
      'Reg Hours': r.regular_hours,
      'Approved OT Hrs': r.approved_overtime_hours,
      'Basic Pay': r.basic_pay,
      'Rest Day Pay': r.rest_day_pay,
      'Special Holiday Pay': r.special_holiday_pay,
      'Regular Holiday Pay': r.regular_holiday_pay,
      'Holiday + Rest Day': r.holiday_rest_day_pay,
      'Overtime Pay': r.regular_overtime_pay + r.rest_day_overtime_pay + r.holiday_overtime_pay,
      Allowances: r.allowances_total,
      Deductions: r.absence_deductions + r.undertime_deductions + r.other_deductions,
      Adjustments: r.adjustments_total,
      'Gross Pay': r.gross_pay,
      'Net Pay': r.net_pay,
    }));
    if (kind === 'xlsx') exportToExcel(`Payroll_${activePeriod.start_date}_${activePeriod.end_date}.xlsx`, 'Payroll', rows);
    else exportToCsv(`Payroll_${activePeriod.start_date}_${activePeriod.end_date}.csv`, rows);
  }

  const inputCls =
    'w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100';

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">
          Payroll Processing &amp; Locked Snapshots
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
          Computes Basic, Rest Day, Special/Regular Holiday, Approved Overtime, Allowances, and Itemized Deductions.
          Finalized periods lock rates and snapshots.
        </p>
      </div>

      {/* Generate New Payroll Period */}
      <form
        onSubmit={handleGenerate}
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-5 space-y-4 shadow-sm dark:shadow-lg dark:shadow-black/30"
      >
        <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">Generate New Payroll Period</h2>
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 text-xs items-end">
          <div className="sm:col-span-2">
            <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Period Name</label>
            <input
              type="text"
              required
              value={periodName}
              onChange={(e) => setPeriodName(e.target.value)}
              className={inputCls}
            />
          </div>
          <div>
            <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Start Date</label>
            <input
              type="date"
              required
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className={`${inputCls} font-mono`}
            />
          </div>
          <div>
            <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">End Date</label>
            <input
              type="date"
              required
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className={`${inputCls} font-mono`}
            />
          </div>
          <div>
            <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Pay Date</label>
            <input
              type="date"
              required
              value={payDate}
              onChange={(e) => setPayDate(e.target.value)}
              className={`${inputCls} font-mono`}
            />
          </div>
        </div>
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={generating}
            className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg inline-flex items-center gap-1.5"
          >
            <Calculator className="w-3.5 h-3.5" />
            {generating ? 'Computing Payroll...' : 'Generate Payroll'}
          </button>
        </div>
      </form>

      {/* Active Payroll Period Selector & Workflow Controls */}
      {payrollPeriods.length === 0 ? (
        <EmptyState
          title="No payroll periods generated"
          description="Select a date range above and click Generate Payroll to compute employee pay."
        />
      ) : (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-5 space-y-5 shadow-sm dark:shadow-lg dark:shadow-black/30">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
            <div className="flex flex-wrap items-center gap-3">
              <select
                value={activePeriod?.id ?? ''}
                onChange={(e) => setSelectedPeriodId(e.target.value)}
                className="px-3 py-2 text-xs font-semibold border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
              >
                {payrollPeriods.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.period_name} ({formatManilaDate(p.start_date)} – {formatManilaDate(p.end_date)})
                  </option>
                ))}
              </select>
              {activePeriod && <StatusLabel label={activePeriod.status} />}
            </div>

            {activePeriod && (
              <div className="flex flex-wrap items-center gap-2">
                {activePeriod.status === 'DRAFT' && (
                  <button
                    type="button"
                    onClick={() => handleStatusTransition(activePeriod, 'FOR_REVIEW')}
                    className="px-3 py-1.5 text-xs font-semibold text-amber-800 dark:text-amber-200 bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 rounded-lg hover:bg-amber-100"
                  >
                    Submit for Review
                  </button>
                )}
                {activePeriod.status === 'FOR_REVIEW' && (
                  <button
                    type="button"
                    onClick={() => handleStatusTransition(activePeriod, 'APPROVED')}
                    className="px-3 py-1.5 text-xs font-semibold text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 rounded-lg hover:bg-blue-100 inline-flex items-center gap-1"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Approve Payroll
                  </button>
                )}
                {(activePeriod.status === 'APPROVED' || activePeriod.status === 'DRAFT') && (
                  <button
                    type="button"
                    onClick={() => setConfirmFinalize(activePeriod)}
                    className="px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 dark:bg-blue-600 hover:bg-slate-800 dark:hover:bg-blue-700 rounded-lg inline-flex items-center gap-1"
                  >
                    <Lock className="w-3.5 h-3.5" />
                    Finalize &amp; Lock
                  </button>
                )}
                {activePeriod.status === 'FINALIZED' && (
                  <button
                    type="button"
                    onClick={() => handleStatusTransition(activePeriod, 'PAID')}
                    className="px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg"
                  >
                    Mark as Paid
                  </button>
                )}
                {periodRecords.length > 0 && (
                  <button
                    type="button"
                    onClick={() =>
                      onOpenPayslips
                        ? onOpenPayslips()
                        : exportMassPayslips8UpPdf(periodRecords, activePeriod, company, '2x4')
                    }
                    className="px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg inline-flex items-center gap-1.5"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    Mass Payslips (8/Sheet)
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => exportPayroll('xlsx')}
                  className="px-2.5 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 inline-flex items-center gap-1"
                >
                  <Download className="w-3.5 h-3.5" />
                  Excel
                </button>
                <button
                  type="button"
                  onClick={() => exportPayroll('csv')}
                  className="px-2.5 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  CSV
                </button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="border border-slate-200 dark:border-slate-700 rounded-lg p-3 bg-slate-50/50 dark:bg-slate-950/60">
              <span className="text-xs text-slate-500 dark:text-slate-400">Employees Processed</span>
              <p className="text-lg font-mono font-bold tabular-nums text-slate-900 dark:text-slate-100">
                {periodRecords.length}
              </p>
            </div>
            <div className="border border-slate-200 dark:border-slate-700 rounded-lg p-3 bg-slate-50/50 dark:bg-slate-950/60">
              <span className="text-xs text-slate-500 dark:text-slate-400">Total Holiday &amp; OT Pay</span>
              <p className="text-lg font-mono font-bold tabular-nums text-amber-700 dark:text-amber-400">
                {formatPeso(totals.holiday + totals.ot)}
              </p>
            </div>
            <div className="border border-slate-200 dark:border-slate-700 rounded-lg p-3 bg-slate-50/50 dark:bg-slate-950/60">
              <span className="text-xs text-slate-500 dark:text-slate-400">Total Gross Pay</span>
              <p className="text-lg font-mono font-bold tabular-nums text-slate-900 dark:text-slate-100">
                {formatPeso(totals.gross)}
              </p>
            </div>
            <div className="border border-slate-200 dark:border-slate-700 rounded-lg p-3 bg-slate-50/50 dark:bg-slate-950/60">
              <span className="text-xs text-slate-500 dark:text-slate-400">Total Net Pay</span>
              <p className="text-lg font-mono font-bold tabular-nums text-blue-700 dark:text-blue-400">
                {formatPeso(totals.net)}
              </p>
            </div>
          </div>

          <div className="overflow-x-auto border border-slate-200 dark:border-slate-700 rounded-lg">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/70 border-b border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-semibold">
                  <th className="py-2.5 px-3 border-r border-slate-200 dark:border-slate-700">Employee</th>
                  <th className="py-2.5 px-2 border-r border-slate-200 dark:border-slate-700">Type</th>
                  <th className="py-2.5 px-2 text-right border-r border-slate-200 dark:border-slate-700">Basic</th>
                  <th className="py-2.5 px-2 text-right border-r border-slate-200 dark:border-slate-700">Rest/Hol</th>
                  <th className="py-2.5 px-2 text-right border-r border-slate-200 dark:border-slate-700">OT Pay</th>
                  <th className="py-2.5 px-2 text-right border-r border-slate-200 dark:border-slate-700">Allow.</th>
                  <th className="py-2.5 px-2 text-right border-r border-slate-200 dark:border-slate-700">Deduct.</th>
                  <th className="py-2.5 px-2 text-right border-r border-slate-200 dark:border-slate-700">Gross</th>
                  <th className="py-2.5 px-2 text-right border-r border-slate-200 dark:border-slate-700">Net Pay</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                {periodRecords.map((r) => {
                  const restHol =
                    r.rest_day_pay + r.special_holiday_pay + r.regular_holiday_pay + r.holiday_rest_day_pay;
                  const otPay = r.regular_overtime_pay + r.rest_day_overtime_pay + r.holiday_overtime_pay;
                  const ded = r.absence_deductions + r.undertime_deductions + r.other_deductions;
                  return (
                    <tr key={r.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/60">
                      <td className="py-2.5 px-3 border-r border-slate-200 dark:border-slate-700">
                        <p className="font-semibold text-slate-900 dark:text-slate-100">{r.employee_name}</p>
                        <p className="font-mono text-slate-500 dark:text-slate-400">
                          {r.employee_number} · {r.department}
                        </p>
                      </td>
                      <td className="py-2.5 px-2 font-mono text-slate-700 dark:text-slate-300 border-r border-slate-200 dark:border-slate-700">
                        {r.salary_type}
                      </td>
                      <td className="py-2.5 px-2 font-mono tabular-nums text-right text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">
                        {formatPeso(r.basic_pay)}
                      </td>
                      <td className="py-2.5 px-2 font-mono tabular-nums text-right text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">
                        {formatPeso(restHol)}
                      </td>
                      <td className="py-2.5 px-2 font-mono tabular-nums text-right text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">
                        {formatPeso(otPay)}
                        <span className="block text-[10px] text-slate-400">{r.approved_overtime_hours}h</span>
                      </td>
                      <td className="py-2.5 px-2 font-mono tabular-nums text-right text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">
                        {formatPeso(r.allowances_total)}
                      </td>
                      <td className="py-2.5 px-2 font-mono tabular-nums text-right text-rose-700 dark:text-rose-400 border-r border-slate-200 dark:border-slate-700">
                        {formatPeso(ded)}
                      </td>
                      <td className="py-2.5 px-2 font-mono tabular-nums text-right text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">
                        {formatPeso(r.gross_pay)}
                      </td>
                      <td className="py-2.5 px-2 font-mono tabular-nums text-right font-bold text-slate-900 dark:text-slate-100 border-r border-slate-200 dark:border-slate-700">
                        {formatPeso(r.net_pay)}
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <div className="flex items-center justify-end gap-1">
                          {!r.is_locked && (
                            <button
                              type="button"
                              onClick={() => setAdjustingRecord(r)}
                              title="Add Adjustment"
                              className="p-1.5 text-slate-600 dark:text-slate-300 hover:text-blue-700 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/60 rounded"
                            >
                              <PlusCircle className="w-3.5 h-3.5" />
                            </button>
                          )}
                          {activePeriod && (
                            <button
                              type="button"
                              onClick={() => exportPayslipPdf(r, activePeriod, company)}
                              title="Download Payslip PDF"
                              className="p-1.5 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/60 rounded"
                            >
                              <FileText className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {adjustingRecord && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 dark:bg-black/70 flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveAdjustment}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl max-w-md w-full p-6 space-y-4 shadow-lg dark:shadow-2xl dark:shadow-black/50"
          >
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Payroll Adjustment — {adjustingRecord.employee_name}
            </h3>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Type</label>
                <select
                  value={adjType}
                  onChange={(e) => setAdjType(e.target.value as 'ADDITION' | 'DEDUCTION')}
                  className={inputCls}
                >
                  <option value="ADDITION">Addition (+)</option>
                  <option value="DEDUCTION">Deduction (-)</option>
                </select>
              </div>
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Amount (₱)</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  required
                  value={adjAmount}
                  onChange={(e) => setAdjAmount(e.target.value)}
                  className={`${inputCls} font-mono`}
                />
              </div>
            </div>
            <div className="text-xs">
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Category</label>
              <input
                type="text"
                required
                value={adjCategory}
                onChange={(e) => setAdjCategory(e.target.value)}
                className={inputCls}
              />
            </div>
            <div className="text-xs">
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Reason *</label>
              <input
                type="text"
                required
                value={adjReason}
                onChange={(e) => setAdjReason(e.target.value)}
                placeholder="Authorized adjustment reason..."
                className={inputCls}
              />
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setAdjustingRecord(null)}
                className="px-4 py-2 text-xs font-medium border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg"
              >
                Apply Adjustment
              </button>
            </div>
          </form>
        </div>
      )}

      <ConfirmDialog
        open={Boolean(confirmFinalize)}
        title="Finalize & Lock Payroll Snapshot?"
        description="Finalizing locks all pay rates, multipliers, attendance references, and amounts so future salary updates cannot alter this historical payroll."
        confirmLabel="Finalize & Lock"
        onConfirm={() => confirmFinalize && handleStatusTransition(confirmFinalize, 'FINALIZED')}
        onCancel={() => setConfirmFinalize(null)}
      />
    </div>
  );
}
