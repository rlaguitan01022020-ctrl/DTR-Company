import type { CompanySettings, PayrollPeriod, PayrollRecord } from '../../types/database';

export interface PayslipTemplateData {
  companyName: string;
  companyLogoUrl: string | null;
  employeeName: string;
  payPeriodLabel: string;
  newRate: number;
  daysWorked: number;
  basicPay: number;
  ot1Hours: number;
  ot1Pay: number;
  ot2Hours: number;
  ot2Pay: number;
  otlSl: number;
  usd: number;
  legalHoliday: number;
  specialHoliday: number;
  grossEarn: number;
  sssShare: number;
  sssShareRemarks: string;
  phicShare: number;
  phicShareRemarks: string;
  pagibigShare: number;
  sssLoan: number;
  pagibigLoan: number;
  coopShare: number;
  coopLoan: number;
  donation: number;
  cashAdvance: number;
  late: number;
  totalDeductions: number;
  netPay: number;
  note: string;
}

const r2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

export function buildPayslipTemplateData(
  record: PayrollRecord,
  period: PayrollPeriod,
  company: CompanySettings
): PayslipTemplateData {
  const snap = record.rate_snapshot ?? ({} as PayrollRecord['rate_snapshot']);
  const newRate =
    record.salary_type === 'DAILY'
      ? snap.daily_rate ?? 0
      : record.salary_type === 'HOURLY'
        ? snap.hourly_rate ?? 0
        : snap.monthly_rate ?? 0;

  const ot1Hours = snap.regular_ot_hours ?? record.approved_overtime_hours ?? 0;
  const ot1Pay = r2(record.regular_overtime_pay ?? 0);
  const ot2Hours = snap.premium_ot_hours ?? 0;
  const ot2Pay = r2((record.rest_day_overtime_pay ?? 0) + (record.holiday_overtime_pay ?? 0));

  const otlSl = r2((record.allowances_total ?? 0) + (record.adjustments_total > 0 ? record.adjustments_total : 0));
  const usd = r2(record.rest_day_pay ?? 0);
  const legalHoliday = r2((record.regular_holiday_pay ?? 0) + (record.holiday_rest_day_pay ?? 0));
  const specialHoliday = r2(record.special_holiday_pay ?? 0);
  const grossEarn = r2(record.gross_pay ?? 0);

  const sssShare = r2(snap.sss_share ?? 0);
  const phicShare = r2(snap.phic_share ?? 0);
  const pagibigShare = r2(snap.pagibig_share ?? 0);
  const sssLoan = r2(snap.sss_loan ?? 0);
  const pagibigLoan = r2(snap.pagibig_loan ?? 0);
  const coopShare = r2(snap.coop_share ?? 0);
  const coopLoan = r2(snap.coop_loan ?? 0);
  const donation = r2(snap.donation ?? 0);
  const cashAdvance = r2(snap.cash_advance ?? 0);

  const itemizedSum = r2(
    sssShare + phicShare + pagibigShare + sssLoan + pagibigLoan + coopShare + coopLoan + donation + cashAdvance
  );
  const unitemizedOther = Math.max(0, r2((record.other_deductions ?? 0) - itemizedSum));
  const negAdj = record.adjustments_total < 0 ? Math.abs(record.adjustments_total) : 0;
  const late = r2((record.absence_deductions ?? 0) + (record.undertime_deductions ?? 0) + unitemizedOther + negAdj);
  const totalDeductions = r2(itemizedSum + late);
  const netPay = r2(record.net_pay ?? 0);

  return {
    companyName: (company.company_name || 'PAYLEDGER PH').toUpperCase(),
    companyLogoUrl: company.company_logo_url ?? null,
    employeeName: record.employee_name,
    payPeriodLabel: period.period_name || `${period.start_date} – ${period.end_date}`,
    newRate: r2(newRate),
    daysWorked: r2(record.days_worked ?? 0),
    basicPay: r2(record.basic_pay ?? 0),
    ot1Hours: r2(ot1Hours),
    ot1Pay,
    ot2Hours: r2(ot2Hours),
    ot2Pay,
    otlSl,
    usd,
    legalHoliday,
    specialHoliday,
    grossEarn,
    sssShare,
    sssShareRemarks: snap.sss_share_remarks?.trim() ?? '',
    phicShare,
    phicShareRemarks: snap.phic_share_remarks?.trim() ?? '',
    pagibigShare,
    sssLoan,
    pagibigLoan,
    coopShare,
    coopLoan,
    donation,
    cashAdvance,
    late,
    totalDeductions,
    netPay,
    note: company.payslip_note?.trim() || 'DEDUCTION ON SSS & PHIC SHARE',
  };
}

export function formatSlipNum(value: number): string {
  return value.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}
