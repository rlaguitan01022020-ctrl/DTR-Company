// Asia/Manila timezone utilities (UTC+8, no DST)

export const MANILA_TZ = 'Asia/Manila';

/**
 * Returns YYYY-MM-DD in Asia/Manila for any Date or ISO timestamp.
 */
export function toManilaDateString(dateInput: Date | string = new Date()): string {
  const date = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: MANILA_TZ,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(date);

  const year = parts.find((p) => p.type === 'year')?.value ?? '2026';
  const month = parts.find((p) => p.type === 'month')?.value ?? '01';
  const day = parts.find((p) => p.type === 'day')?.value ?? '01';
  return `${year}-${month}-${day}`;
}

/**
 * Returns HH:mm:ss in Asia/Manila 24-hour clock.
 */
export function toManilaTime24(dateInput: Date | string = new Date()): string {
  const date = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: MANILA_TZ,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  }).formatToParts(date);

  const hour = parts.find((p) => p.type === 'hour')?.value ?? '00';
  const minute = parts.find((p) => p.type === 'minute')?.value ?? '00';
  const second = parts.find((p) => p.type === 'second')?.value ?? '00';
  return `${hour === '24' ? '00' : hour}:${minute}:${second}`;
}

/**
 * Formats ISO timestamp into 24-hour Manila time like "08:00" or "17:30".
 */
export function formatManilaTime(dateInput: Date | string | null | undefined): string {
  if (!dateInput) return '—';
  const date = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
  if (Number.isNaN(date.getTime())) return '—';
  const formatted = new Intl.DateTimeFormat('en-GB', {
    timeZone: MANILA_TZ,
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(date);
  return formatted.startsWith('24:') ? `00:${formatted.slice(3)}` : formatted;
}

/**
 * Formats YYYY-MM-DD or ISO timestamp into readable Philippine date.
 */
export function formatManilaDate(dateInput: Date | string | null | undefined): string {
  if (!dateInput) return '—';
  const date =
    typeof dateInput === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(dateInput)
      ? new Date(`${dateInput}T00:00:00+08:00`)
      : new Date(dateInput);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat('en-PH', {
    timeZone: MANILA_TZ,
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  }).format(date);
}

/**
 * Builds an Asia/Manila ISO timestamptz string from YYYY-MM-DD and HH:mm(:ss).
 */
export function buildManilaTimestamp(dateStr: string, timeStr: string): string {
  const normalizedTime = timeStr.length === 5 ? `${timeStr}:00` : timeStr;
  return new Date(`${dateStr}T${normalizedTime}+08:00`).toISOString();
}

/**
 * Adds N calendar days to a YYYY-MM-DD string.
 */
export function addDaysToDateString(dateStr: string, days: number): string {
  const d = new Date(`${dateStr}T00:00:00+08:00`);
  d.setUTCDate(d.getUTCDate() + days);
  return toManilaDateString(d);
}

/**
 * Returns day of week (0 = Sunday .. 6 = Saturday) for a YYYY-MM-DD in Asia/Manila.
 */
export function getManilaDayOfWeek(dateStr: string): number {
  const d = new Date(`${dateStr}T12:00:00+08:00`);
  const weekday = new Intl.DateTimeFormat('en-US', {
    timeZone: MANILA_TZ,
    weekday: 'short',
  }).format(d);
  const map: Record<string, number> = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
  return map[weekday] ?? 0;
}

/**
 * Derives the employee's work_date for a given timestamp & schedule, handling overnight shifts.
 */
export function deriveWorkDate(
  timestamp: Date | string,
  schedule: { time_in: string; is_overnight: boolean },
  hasOpenPriorShift = false
): string {
  const currentDate = toManilaDateString(timestamp);
  if (!schedule.is_overnight) return currentDate;

  const currentTime24 = toManilaTime24(timestamp);
  if (hasOpenPriorShift && currentTime24 < schedule.time_in) {
    return addDaysToDateString(currentDate, -1);
  }
  return currentDate;
}

/**
 * Enumerates YYYY-MM-DD dates between startDate and endDate inclusive.
 */
export function enumerateDateRange(startDate: string, endDate: string): string[] {
  const dates: string[] = [];
  let cursor = startDate;
  let guard = 0;
  while (cursor <= endDate && guard < 400) {
    dates.push(cursor);
    cursor = addDaysToDateString(cursor, 1);
    guard += 1;
  }
  return dates;
}

export function formatPeso(amount: number): string {
  return new Intl.NumberFormat('en-PH', {
    style: 'currency',
    currency: 'PHP',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(Number.isFinite(amount) ? amount : 0);
}
