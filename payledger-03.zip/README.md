# PayLedger PH — Employee Management, Employee Number Attendance, DTR, Overtime, Holiday Pay & Payroll System

Production-ready HR, Attendance, DTR, Holiday Pay, and Payroll application built with **React + TypeScript + Vite**, powered by **Supabase (PostgreSQL, Auth, Storage, RLS, Edge Functions)**, and deployed globally on **Cloudflare (Cloudflare Pages / Cloudflare Workers Static Assets)**.

- **Hosting & Global Edge Delivery:** Cloudflare global edge network (replaces single-region servers with worldwide low-latency edge caching and SPA routing via `wrangler.jsonc`, `public/_redirects`, and `public/_headers`).
- **Authentication:** Supabase Email & Password Auth (all user profile data is stored in `public.profiles`).
- **Attendance Verification:** Employee Number Terminal & Full-Screen Entrance Kiosk (24-hour `Asia/Manila` clock).
- **Timezone & Currency:** `Asia/Manila` (`UTC+8`) and Philippine Peso (`₱`).

---

## 1. Local Development Setup

```bash
npm install
cp .env.example .env
```

Fill in `.env` with your Supabase project credentials:

```env
VITE_SUPABASE_URL=https://mmoebxqfovvwzcvoduyz.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
```

Start the dev server:

```bash
npm run dev
```

Run tests, typecheck, and production build:

```bash
npm test
npm run lint
npm run build
```

---

## 2. Cloudflare Global Deployment (No Single Region)

### Option A: Cloudflare Pages (GitHub Integration)
1. Connect your repository in **Cloudflare Dashboard → Workers & Pages → Create → Pages**.
2. Set the build settings:
   - **Framework preset:** `Vite`
   - **Build command:** `npm run build`
   - **Build output directory:** `dist`
3. Add Environment Variables under **Settings → Environment Variables**:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
4. SPA routing (`public/_redirects`) and immutable caching/security headers (`public/_headers`) are applied automatically across all Cloudflare edge locations worldwide.

### Option B: Cloudflare Workers Static Assets (`wrangler.jsonc`)
Deploy directly from the CLI using the included `wrangler.jsonc`:

```bash
npx wrangler login
npm run deploy:cloudflare
```

---

## 3. Supabase Database & Migration Setup

Apply the SQL migrations in order via the Supabase CLI or the Supabase SQL Editor:

1. `supabase/migrations/0001_initial_schema.sql` — Tables, constraints, unique keys, and indexes.
2. `supabase/migrations/0002_rls_and_functions.sql` — Row Level Security policies, `profiles` sync trigger, `provision_first_super_admin`, and atomic `record_employee_number_attendance`.
3. `supabase/migrations/0003_storage_buckets.sql` — `employee-photos`, `company-assets`, `leave-attachments`, and `payslips` buckets and policies.
4. `supabase/migrations/0004_seed_defaults.sql` — Default `8:00 AM - 5:00 PM` schedule (`Asia/Manila`), company settings, and official 2026 Philippine holidays.
5. `supabase/migrations/0005_theme_and_deductions.sql` — Light/Dark theme setting, payslip footer note, and itemized employee deductions & remarks.

Via Supabase CLI:

```bash
supabase link --project-ref YOUR_PROJECT_REF
supabase db push
```

---

## 4. Deploy Supabase Edge Functions & First Super Admin Provisioning

```bash
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
supabase functions deploy provision-super-admin
supabase functions deploy record-attendance
```

To provision the first **Super Admin**, sign up / create your initial user via Supabase Auth or the **Initial Super Admin Setup** dialog on the login screen when zero active `SUPER_ADMIN` profiles exist. Once one Super Admin exists, public Super Admin provisioning is permanently locked.

---

## 5. Entrance Kiosk Setup (Windows / Android)

- Open **Attendance Kiosk** and click **MAXIMIZE** for full-screen Employee Number check-in/out.
- **Windows:** Configure Edge/Chrome in Kiosk Mode (`msedge.exe --kiosk https://your-cloudflare-domain --edge-kiosk-type=fullscreen`) and set Power Options -> Screen/Sleep to `Never`.
- **Android:** Use Chrome "Add to Home Screen" or Android Screen Pinning / Managed Kiosk mode, and enable "Stay awake while charging" in Developer Options.
